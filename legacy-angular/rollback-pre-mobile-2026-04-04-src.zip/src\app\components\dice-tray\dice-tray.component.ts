import { Component, ChangeDetectionStrategy, inject, computed, signal, viewChildren } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { GameStateService } from '../../services/game-state.service';
import { DiceService } from '../../services/dice.service';
import { CombatService } from '../../services/combat.service';
import { ProtocolService } from '../../services/protocol.service';
import {
  RerollAnimationRequestService,
  RerollAnimationPayload,
} from '../../services/reroll-animation-request.service';
import { HeroState } from '../../models/hero.interface';
import { EnemyState } from '../../models/enemy.interface';
import { ZONE_COLORS } from '../../models/types';
import { DieComponent } from './die/die.component';

const NEUTRAL = '#2a3a50';
const ANIM_TICK_MS = 70;
const ANIM_STEPS = 8;
const ANIM_REVEAL_STEP = 6;
const ROW_W = 736;
const ROW_H = 64;
const DIE_W = 48; // mc-slot approximate width
const DIE_H = 48;
const PAD = 3;

interface PrecomputedRoll {
  heroIdx: number;
  finalRoll: number;
}

interface PrecomputedEnemyRoll {
  enemyIdx: number;
  preRoll: number;
  /** Effective roll after enemy rfe (for face + zone color during reveal) */
  displayEff: number;
}

interface JitterPos {
  left: string;
  top: string;
}

@Component({
  selector: 'app-dice-tray',
  standalone: true,
  imports: [DieComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="dice-tray-wrap">
      <div class="shared-dice-tray">
        <div class="tray-split">
          <!-- Enemy dice -->
          <div class="tray-band">
            <div class="tray-dice-row tray-dice-row--enemies"
                 [class.tray-dice-row--spread]="state.enemies().length >= 3"
                 [class.tray-dice-row--center]="state.enemies().length < 3"
                 [class.tray-dice-row--roll-float]="fullTrayRollPhase()">
              @for (enemy of state.enemies(); track enemy.id; let i = $index) {
                <div class="tray-unit-col"
                     [class.tray-unit-col--float]="fullTrayRollPhase() && !enemy.dead"
                     [style.left]="enemyJitter()[i]?.left ?? null"
                     [style.top]="enemyJitter()[i]?.top ?? null">
                  <div class="tray-enemy-slot">
                    @if (!enemy.dead) {
                      <app-die
                        [roll]="hideEnemyRolls() ? null : enemy.effRoll"
                        [color]="hideEnemyRolls() ? NEUTRAL : getEnemyDieColor(enemy.effRoll)"
                        [clickable]="false"
                        [animDisplay]="enemyAnimDisplays()[i] ?? null"
                        [animColor]="enemyAnimColors()[i] ?? null" />
                    } @else {
                      <div class="tray-die-spacer" aria-hidden="true"></div>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Mid bar - action button -->
          <div class="tray-mid-bar">
            @if (isAnimating()) {
              <button class="btn-main end" disabled>
                <span class="ma-label">Rolling...</span><span class="ma-arrow">▶</span>
              </button>
            } @else if (!state.allHeroesRolled()) {
              <button class="btn-main roll btn-main--accent" (click)="onRollAll()"
                      [disabled]="state.rollAllInProgress() || state.rollAnimInProgress()">
                <span class="ma-arrow">▶</span> ROLL ALL DICE
              </button>
            } @else {
              <button class="btn-main end" (click)="onEndTurn()"
                      [disabled]="!state.allHeroesReady() || state.phase() !== 'player' || isAnimating()">
                END TURN <span class="ma-arrow">▶</span>
              </button>
            }
          </div>

          <!-- Squad dice -->
          <div class="tray-band">
            <div class="tray-dice-row tray-dice-row--squad"
                 [class.tray-dice-row--roll-float]="fullTrayRollPhase()">
              @for (hero of state.heroes(); track hero.id; let i = $index) {
                <div class="tray-unit-col"
                     [class.tray-unit-col--float]="fullTrayRollPhase() && hero.currentHp > 0 && (hero.roll === null || rerollingHeroIdx() === i)"
                     [style.left]="heroJitter()[i]?.left ?? null"
                     [style.top]="heroJitter()[i]?.top ?? null">
                  <div class="mc-slot mc-slot--squad">
                    <!-- Keep one #heroDie per index so viewChildren matches hero slots after mid-round deaths -->
                    <app-die #heroDie
                      [class.tray-die--dead]="hero.currentHp <= 0"
                      [roll]="getHeroDisplayRoll(hero)"
                      [color]="getHeroDieColor(hero)"
                      [clickable]="hero.currentHp > 0 && hero.roll === null && state.phase() === 'player' && !isAnimating()"
                      [displayText]="getHeroDisplayText(hero)"
                      [animDisplay]="heroAnimDisplays()[i] ?? null"
                      [animColor]="heroAnimColors()[i] ?? null"
                      (dieClicked)="onRollHero(i)" />
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dice-tray-wrap { width: 736px; margin: 0 auto 4px; display: flex; justify-content: center; }
    .shared-dice-tray {
      width: 100%; background: linear-gradient(180deg, rgba(17,29,46,.95), rgba(8,12,18,.92));
      border: 1px solid var(--border2); border-radius: 8px;
      box-shadow: 0 0 0 1px rgba(46,125,212,.12), inset 0 1px 0 rgba(255,255,255,.04);
      padding: 4px 0 5px; position: relative;
    }
    .shared-dice-tray::before {
      content: ''; position: absolute; left: 0; right: 0; top: 4px; bottom: 4px;
      border-radius: 6px; border: 1px solid rgba(232,184,74,.1); pointer-events: none;
    }
    .tray-split { display: flex; flex-direction: column; align-items: stretch; gap: 0; }
    .tray-band { display: flex; flex-direction: column; align-items: stretch; gap: 0; padding: 0; position: relative; }
    .tray-mid-bar { display: flex; justify-content: center; align-items: center; padding: 4px; margin: 0; }
    .tray-unit-col { flex: 0 0 240px; max-width: 240px; display: flex; justify-content: center; align-items: center; box-sizing: border-box; min-height: 0; }
    .tray-dice-row { display: flex; flex-wrap: nowrap; align-items: center; width: 736px; max-width: 100%; margin: 0; padding: 0; min-height: 64px; box-sizing: border-box; gap: 8px; }
    .tray-dice-row--squad { display: grid; grid-template-columns: repeat(3, 240px); gap: 8px; width: 736px; height: 64px; min-height: 64px; align-items: center; align-content: center; }
    .tray-dice-row--enemies.tray-dice-row--spread { display: grid; grid-template-columns: repeat(3, 240px); gap: 8px; width: 736px; min-height: 64px; align-items: center; }
    .tray-dice-row--enemies.tray-dice-row--center { display: flex; justify-content: center; min-height: 64px; align-items: center; }
    .tray-enemy-slot { padding: 0; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .mc-slot {
      width: auto; min-width: 0; flex: 0 0 auto; display: flex; align-items: center; justify-content: center; gap: 4px;
      border-radius: 6px; padding: 4px 6px; background: rgba(13,21,32,.85); border: 1px solid #1e3a5f;
    }
    /* Squad row: bare die (legacy tray-dice-row--squad .mc-slot) */
    .mc-slot--squad {
      padding: 0; border: none; border-radius: 0; background: transparent; box-shadow: none;
    }
    :host ::ng-deep app-die.tray-die--dead .die-wrap {
      visibility: hidden;
      pointer-events: none;
    }
    .tray-die-spacer { width: 40px; height: 40px; flex-shrink: 0; }

    /* Float mode: switch from grid to positioned block so dice can fly around */
    .tray-dice-row--roll-float {
      display: block !important;
      position: relative;
      width: 736px;
      height: 64px;
      min-height: 64px;
      overflow: hidden;
    }
    .tray-dice-row--roll-float .tray-unit-col--float {
      position: absolute;
      display: block;
      width: auto;
      max-width: none;
      flex: none !important;
      margin: 0 !important;
      transition: none;
    }
    .tray-dice-row--roll-float .mc-slot { position: static; margin: 0 !important; }
    .tray-dice-row--roll-float .tray-enemy-slot { position: static; margin: 0 !important; }

    .btn-main {
      font-family: 'Share Tech Mono', monospace; font-weight: 900; font-size: 10px; letter-spacing: 1px;
      text-transform: uppercase; padding: 4px 10px; height: 26px; min-width: 160px; max-width: 240px;
      border-radius: 3px; cursor: pointer; border: 1px solid; white-space: nowrap;
    }
    .btn-main:disabled { opacity: .35; cursor: not-allowed; }
    .btn-main.roll { border-color: var(--strike); color: var(--strike); background: rgba(46,125,212,.10); }
    .btn-main.roll.btn-main--accent {
      border-color: #5ca6ff; color: #cfe6ff; background: rgba(46,125,212,.22);
      box-shadow: 0 0 0 1px rgba(46,125,212,.5), 0 0 22px rgba(46,125,212,.28);
    }
    .btn-main.roll.btn-main--accent:hover:not(:disabled) { filter: brightness(1.06); border-color: #7ab8ff; }
    .btn-main.end { border-color: rgba(232,184,74,.55); color: #e8b84a; background: rgba(232,184,74,.10); }
    .btn-main.end:hover:not(:disabled) { border-color: #e8b84a; filter: brightness(1.05); }
    .ma-arrow { display: inline-block; width: 14px; text-align: center; opacity: .95; }
  `],
})
export class DiceTrayComponent {
  state = inject(GameStateService);
  private dice = inject(DiceService);
  private combat = inject(CombatService);
  private protocol = inject(ProtocolService);
  private rerollRequests = inject(RerollAnimationRequestService);

  NEUTRAL = NEUTRAL;
  ANIM_REVEAL_STEP = ANIM_REVEAL_STEP;

  heroDieRefs = viewChildren<DieComponent>('heroDie');

  constructor() {
    this.rerollRequests.requests$.pipe(takeUntilDestroyed()).subscribe(p => this.playRerollAnimation(p));
  }

  // ── Animation state ──
  isAnimating = signal(false);
  animStep = signal(0);
  /** Protocol reroll: this slot jitters even though `roll` is already set */
  rerollingHeroIdx = signal<number | null>(null);

  heroAnimDisplays = signal<(string | null)[]>([]);
  heroAnimColors = signal<(string | null)[]>([]);
  enemyAnimDisplays = signal<(string | null)[]>([]);
  enemyAnimColors = signal<(string | null)[]>([]);

  /** Random positions for each hero die slot during jitter phase */
  heroJitter = signal<(JitterPos | null)[]>([]);
  /** Random positions for each enemy die slot during jitter phase */
  enemyJitter = signal<(JitterPos | null)[]>([]);

  /** Jitter/reveal layout for whole tray — off during protocol reroll so other dice stay in grid. */
  fullTrayRollPhase = computed(
    () => this.isAnimating() && this.animStep() < this.ANIM_REVEAL_STEP && this.rerollingHeroIdx() === null,
  );

  /** Match enemy-zone: hide enemy faces until squad is fully rolled, tray is revealed, and roll-all anim finished (not solo reroll). */
  hideEnemyRolls = computed(() => {
    if (this.state.phase() !== 'player') return false;
    if (!this.state.allHeroesRolled()) return true;
    if (this.isAnimating() && this.rerollingHeroIdx() === null) return true;
    return !this.state.enemyTrayRevealed();
  });

  // ── Roll animation ──

  onRollAll(): void {
    if (this.state.phase() !== 'player' || this.state.rollAllInProgress() || this.isAnimating()) return;

    const heroes = this.state.heroes();
    const enemies = this.state.enemies();

    const heroRolls: PrecomputedRoll[] = [];
    for (let i = 0; i < heroes.length; i++) {
      const h = heroes[i];
      if (h.currentHp <= 0 || h.roll !== null) continue;
      let raw = this.dice.d20();
      const rfmPen = this.state.rfmPen();
      if (rfmPen > 0) raw = Math.max(1, raw - rfmPen);
      const buffed = h.rollBuff > 0 ? Math.min(20, raw + h.rollBuff) : raw;
      heroRolls.push({ heroIdx: i, finalRoll: buffed });
    }

    const enemyRolls: PrecomputedEnemyRoll[] = [];
    for (let i = 0; i < enemies.length; i++) {
      const e = enemies[i];
      if (e.dead) continue;
      const preRoll = this.dice.d20();
      const displayEff = Math.max(1, preRoll - (e.rfe || 0));
      enemyRolls.push({ enemyIdx: i, preRoll, displayEff });
    }

    if (!heroRolls.length && !enemyRolls.length) return;

    this.runMultiDieAnimation({
      heroes,
      enemies,
      heroRolls,
      enemyRolls,
      rerollHeroIdx: null,
      progressFlag: 'rollAll',
      onFinished: () => {
        for (const hr of heroRolls) {
          this.state.updateHero(hr.heroIdx, {
            roll: hr.finalRoll,
            rawRoll: hr.finalRoll,
            noRR: true,
          });
          this.combat.clearAndAutoTarget(hr.heroIdx);
        }
        if (enemyRolls.length) {
          this.combat.applyEnemyAbilityRollsFromPreRolls(
            enemyRolls.map(er => ({ enemyIndex: er.enemyIdx, preRoll: er.preRoll })),
          );
        }
        this.state.enemyTrayRevealed.set(true);
      },
    });
  }

  private playRerollAnimation(p: RerollAnimationPayload): void {
    if (this.state.phase() !== 'player' || this.isAnimating()) return;
    const rolled = this.protocol.drawRerollForAnimation(p.heroIdx);
    if (!rolled) return;
    const heroes = this.state.heroes();
    const enemies = this.state.enemies();
    const hi = p.heroIdx;

    this.runMultiDieAnimation({
      heroes,
      enemies,
      heroRolls: [{ heroIdx: hi, finalRoll: rolled.displayRoll }],
      enemyRolls: [],
      rerollHeroIdx: hi,
      progressFlag: 'rollAnim',
      onFinished: () => {
        this.protocol.commitReroll(hi, rolled.rawRoll, rolled.displayRoll);
        this.combat.clearAndAutoTarget(hi);
      },
    });
  }

  private runMultiDieAnimation(args: {
    heroes: HeroState[];
    enemies: EnemyState[];
    heroRolls: PrecomputedRoll[];
    enemyRolls: PrecomputedEnemyRoll[];
    rerollHeroIdx: number | null;
    progressFlag: 'rollAll' | 'rollAnim';
    onFinished: () => void;
  }): void {
    const { heroes, enemies, heroRolls, enemyRolls, rerollHeroIdx, progressFlag, onFinished } = args;
    if (this.isAnimating()) return;

    this.isAnimating.set(true);
    this.rerollingHeroIdx.set(rerollHeroIdx);
    if (progressFlag === 'rollAll') this.state.rollAllInProgress.set(true);
    else this.state.rollAnimInProgress.set(true);

    const rollingHeroSet = new Set(heroRolls.map(r => r.heroIdx));
    const rollingEnemySet = new Set(enemyRolls.map(r => r.enemyIdx));

    let step = 0;

    const interval = setInterval(() => {
      step++;
      this.animStep.set(step);

      const heroDisplays: (string | null)[] = heroes.map(() => null);
      const heroColors: (string | null)[] = heroes.map(() => null);
      const enemyDisplays: (string | null)[] = enemies.map(() => null);
      const enemyColors: (string | null)[] = enemies.map(() => null);

      if (step < ANIM_REVEAL_STEP) {
        for (const hr of heroRolls) {
          heroDisplays[hr.heroIdx] = String(Math.floor(Math.random() * 20) + 1);
          heroColors[hr.heroIdx] = NEUTRAL;
        }
        for (const er of enemyRolls) {
          enemyDisplays[er.enemyIdx] = String(Math.floor(Math.random() * 20) + 1);
          enemyColors[er.enemyIdx] = NEUTRAL;
        }

        const maxHeroL = Math.max(0, ROW_W - DIE_W - PAD * 2);
        const maxT = Math.max(0, ROW_H - DIE_H - PAD * 2);
        const hJitter: (JitterPos | null)[] =
          rerollHeroIdx !== null
            ? heroes.map(() => null)
            : heroes.map((_, i) => {
                if (!rollingHeroSet.has(i)) return null;
                return {
                  left: (PAD + Math.random() * maxHeroL) + 'px',
                  top: (PAD + Math.random() * maxT) + 'px',
                };
              });

        const minEnemyL = ROW_W / 2 + PAD;
        const enemySpan = Math.max(0, ROW_W - DIE_W - PAD - minEnemyL);
        const eJitter: (JitterPos | null)[] =
          rerollHeroIdx !== null
            ? enemies.map(() => null)
            : enemies.map((e, i) => {
                if (!rollingEnemySet.has(i) || e.dead) return null;
                return {
                  left: (minEnemyL + Math.random() * enemySpan) + 'px',
                  top: (PAD + Math.random() * maxT) + 'px',
                };
              });

        this.heroJitter.set(hJitter);
        this.enemyJitter.set(eJitter);
      } else {
        for (const hr of heroRolls) {
          const heroId = heroes[hr.heroIdx].id;
          const z = this.dice.getHeroZone(hr.finalRoll, heroId);
          const fc = ZONE_COLORS[z] || '#4a6a8a';
          heroDisplays[hr.heroIdx] = String(hr.finalRoll);
          heroColors[hr.heroIdx] = fc;
        }
        for (const er of enemyRolls) {
          const z = this.dice.getEnemyZone(er.displayEff);
          const fc = ZONE_COLORS[z] || '#4a6a8a';
          enemyDisplays[er.enemyIdx] = String(er.displayEff);
          enemyColors[er.enemyIdx] = fc;
        }

        this.heroJitter.set([]);
        this.enemyJitter.set([]);

        if (step === ANIM_REVEAL_STEP) {
          const dieRefs = this.heroDieRefs();
          for (const hr of heroRolls) {
            dieRefs[hr.heroIdx]?.triggerBounce();
          }
        }
      }

      this.heroAnimDisplays.set(heroDisplays);
      this.heroAnimColors.set(heroColors);
      this.enemyAnimDisplays.set(enemyDisplays);
      this.enemyAnimColors.set(enemyColors);

      if (step >= ANIM_STEPS) {
        clearInterval(interval);

        setTimeout(() => {
          this.heroAnimDisplays.set([]);
          this.heroAnimColors.set([]);
          this.enemyAnimDisplays.set([]);
          this.enemyAnimColors.set([]);
          this.heroJitter.set([]);
          this.enemyJitter.set([]);
          this.rerollingHeroIdx.set(null);
          this.animStep.set(0);

          onFinished();

          if (progressFlag === 'rollAll') this.state.rollAllInProgress.set(false);
          else this.state.rollAnimInProgress.set(false);
          this.isAnimating.set(false);
        }, 150);
      }
    }, ANIM_TICK_MS);
  }

  onRollHero(i: number): void {
    if (this.isAnimating()) return;
    this.combat.rollHero(i);
  }

  onEndTurn(): void {
    if (this.isAnimating()) return;
    this.combat.endTurn();
  }

  // ── Display helpers ──

  getEnemyDieColor(effRoll: number): string {
    const zone = this.dice.getEnemyZone(effRoll);
    return ZONE_COLORS[zone] || '#2a3a50';
  }

  getHeroDisplayRoll(hero: HeroState): number | null {
    if (hero.currentHp <= 0 || hero.roll === null) return null;
    return this.dice.effRoll(hero);
  }

  getHeroDisplayText(hero: HeroState): string | null {
    if (hero.currentHp <= 0 || hero.roll === null) return null;
    const er = this.dice.effRoll(hero);
    if (er === null) return null;

    if ((hero.rollNudge || 0) > 0) return String(er);
    const rb = hero.rollBuff || 0;
    let s = String(hero.roll);
    if (rb > 0) s += `+${rb}`;
    if (s !== String(er)) return `${s}→${er}`;
    return String(er);
  }

  getHeroDieColor(hero: HeroState): string {
    if (hero.currentHp <= 0) return NEUTRAL;
    const er = this.dice.effRoll(hero);
    if (er === null) return '#2a3a50';
    const zone = this.dice.getHeroZone(er, hero.id);
    return ZONE_COLORS[zone] || '#4a6a8a';
  }
}
