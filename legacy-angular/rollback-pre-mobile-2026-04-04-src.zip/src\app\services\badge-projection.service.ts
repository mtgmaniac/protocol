import { Injectable } from '@angular/core';
import { HeroState } from '../models/hero.interface';
import { EnemyState } from '../models/enemy.interface';
import { HeroId } from '../models/types';
import { GameStateService } from './game-state.service';
import { DiceService } from './dice.service';

export interface HeroBadgeSnapshot {
  incomingDmg: number;
  incomingHeal: number;
  incomingShield: number;
  /** Net roll change from this turn’s resolutions: ally +rfm targeting this hero minus global enemy −rfm (same − for everyone). */
  incomingRollNet: number;
  statusShield: number;
  statusDot: number;
  statusDotT: number;
  netRollMod: number;
}

export interface EnemyBadgeSnapshot {
  incomingDmg: number;
  incomingRfe: number;
  incomingDot: number;
  statusShield: number;
  statusShieldT: number;
  statusDot: number;
  statusDotT: number;
  statusRfe: number;
  statusRfT: number;
}

@Injectable({ providedIn: 'root' })
export class BadgeProjectionService {
  constructor(
    private state: GameStateService,
    private dice: DiceService,
  ) {}

  /** End-turn previews (incoming from enemies / from squad) only after every living hero has a roll. */
  private showTurnPreviews(): boolean {
    return this.state.heroes().every(x => x.currentHp <= 0 || x.roll !== null);
  }

  heroBadges(heroIndex: number): HeroBadgeSnapshot {
    const h = this.state.heroes()[heroIndex];
    if (!h) {
      return {
        incomingDmg: 0,
        incomingHeal: 0,
        incomingShield: 0,
        incomingRollNet: 0,
        statusShield: 0,
        statusDot: 0,
        statusDotT: 0,
        netRollMod: 0,
      };
    }
    const netRollMod = (h.rollBuff || 0) - this.state.rfmPen();
    const pre = this.showTurnPreviews();
    const incomingRollNet = pre
      ? this.incomingRollBuffFromAlliesFor(heroIndex) - this.incomingEnemyRfmTotalNextTurn()
      : 0;
    return {
      incomingDmg: pre ? this.incomingFor(h.id) : 0,
      incomingHeal: pre ? this.incomingHealFor(h.id) : 0,
      incomingShield: pre ? this.incomingShieldFor(h.id) : 0,
      incomingRollNet,
      statusShield: h.shield > 0 && h.shT > 0 ? h.shield : 0,
      statusDot: h.dot > 0 && h.dT > 0 ? h.dot : 0,
      statusDotT: h.dT || 0,
      netRollMod,
    };
  }

  /** +rfm from squad abilities this player turn that apply to this hero (ally pick or self). */
  private incomingRollBuffFromAlliesFor(heroIdx: number): number {
    const heroes = this.state.heroes();
    const tgt = heroes[heroIdx];
    if (!tgt || tgt.currentHp <= 0) return 0;
    let tot = 0;
    for (let i = 0; i < heroes.length; i++) {
      const h = heroes[i];
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab?.rfm || ab.rfm <= 0) continue;
      if (ab.rfmTgt) {
        if (h.rfmTgtIdx === null) continue;
        if (h.rfmTgtIdx === heroIdx) tot += ab.rfm;
      } else if (i === heroIdx) {
        tot += ab.rfm;
      }
    }
    return tot;
  }

  /** Sum of −roll (rfm) enemies will apply globally on the upcoming enemy phase. */
  private incomingEnemyRfmTotalNextTurn(): number {
    let t = 0;
    for (const e of this.state.enemies()) {
      if (e.dead || !e.plan?.rfm) continue;
      t += e.plan.rfm;
    }
    return t;
  }

  enemyBadges(enemyIndex: number): EnemyBadgeSnapshot {
    const enemies = this.state.enemies();
    const e = enemies[enemyIndex];
    if (!e) {
      return {
        incomingDmg: 0,
        incomingRfe: 0,
        incomingDot: 0,
        statusShield: 0,
        statusShieldT: 0,
        statusDot: 0,
        statusDotT: 0,
        statusRfe: 0,
        statusRfT: 0,
      };
    }
    const pre = this.showTurnPreviews();
    const dotIn = pre ? this.incomingDotDetailForEnemy(enemyIndex) : { dot: 0, dT: 0 };
    return {
      incomingDmg: pre ? this.projDmgOn(enemyIndex) : 0,
      incomingRfe: pre ? this.incomingRfeForEnemy(enemyIndex) : 0,
      incomingDot: dotIn.dot,
      statusShield: e.shield > 0 && e.shT > 0 ? e.shield : 0,
      statusShieldT: e.shT || 0,
      statusDot: e.dot > 0 && e.dT > 0 ? e.dot : 0,
      statusDotT: e.dT || 0,
      statusRfe: e.rfe > 0 && e.rfT > 0 ? e.rfe : 0,
      statusRfT: e.rfT || 0,
    };
  }

  /**
   * Net HP damage this enemy will take from hero abilities this turn, in hero resolution order,
   * with shield depletion and pierce matching {@link CombatService} (endTurn player loop).
   */
  projDmgOn(ei: number): number {
    const enemies = this.state.enemies();
    const e = enemies[ei];
    if (!e || e.dead) return 0;

    let shieldRem = e.shield > 0 && e.shT > 0 ? e.shield : 0;
    let hpDmg = 0;

    const applyToEnemy = (dmg: number, ignSh: boolean): void => {
      if (dmg <= 0) return;
      if (ignSh) {
        hpDmg += dmg;
        return;
      }
      const absorbed = Math.min(shieldRem, dmg);
      shieldRem -= absorbed;
      hpDmg += dmg - absorbed;
    };

    for (const h of this.state.heroes()) {
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab || !(ab.dmg || 0)) continue;

      const ignSh = !!ab.ignSh;
      const hTgt = h.lockedTarget !== undefined && h.lockedTarget !== null ? h.lockedTarget : null;

      if (ab.splitDmg) {
        const alloc = h.splitAlloc || {};
        const entries = Object.entries(alloc).filter(([, v]) => v > 0);
        let d = 0;
        if (entries.length) {
          d = alloc[e.id] ?? 0;
        } else if (hTgt != null && hTgt === ei) {
          const tgtE = enemies[hTgt];
          if (tgtE && !tgtE.dead) d = ab.dmg || 0;
        }
        applyToEnemy(d, ignSh);
        continue;
      }

      if (ab.blastAll || ab.multiHit) {
        applyToEnemy(ab.dmg || 0, ignSh);
        continue;
      }

      if (hTgt !== ei) continue;
      applyToEnemy(ab.dmg || 0, ignSh);
    }

    return hpDmg;
  }

  /**
   * Net HP damage from enemy attacks this turn (next enemy phase), in enemy index order,
   * with hero shield depletion. Cloak ignored (expected damage).
   */
  incomingFor(hid: HeroId): number {
    const heroes = this.state.heroes();
    const h = heroes.find(x => x.id === hid);
    if (!h || h.currentHp <= 0) return 0;

    let shieldRem = h.shield > 0 && h.shT > 0 ? h.shield : 0;
    let hpDmg = 0;

    for (const e of this.state.enemies()) {
      if (e.dead || !e.plan || e.targeting !== hid) continue;
      const dmgAmt = this.enemyAttackDamagePreview(e);
      if (dmgAmt <= 0) continue;

      const absorbed = Math.min(shieldRem, dmgAmt);
      shieldRem -= absorbed;
      hpDmg += dmgAmt - absorbed;
    }

    return hpDmg;
  }

  private enemyAttackDamagePreview(e: EnemyState): number {
    if (!e.plan) return 0;
    if (e.plan.dmg != null && e.plan.dmg > 0) return e.plan.dmg;
    const dMin = e.p2 ? (e.p2dMin ?? e.dMin) : e.dMin;
    const dMax = e.p2 ? (e.p2dMax ?? e.dMax) : e.dMax;
    return Math.round((dMin + dMax) / 2);
  }

  incomingHealFor(hid: HeroId): number {
    const heroes = this.state.heroes();
    let tot = 0;

    for (const h of heroes) {
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab || !ab.heal) continue;

      if (ab.healAll) {
        tot += ab.heal;
        continue;
      }
      if (ab.healLowest) {
        const alive = heroes.filter(x => x.currentHp > 0);
        if (!alive.length) continue;
        const lowest = alive.reduce((a, b) => (a.currentHp < b.currentHp ? a : b));
        if (lowest.id === hid) tot += ab.heal;
        continue;
      }
      if (ab.healTgt) {
        if (h.healTgtIdx == null) continue;
        const healTarget = heroes[h.healTgtIdx];
        if (healTarget?.id === hid) tot += ab.heal;
        continue;
      }
      if (h.id === hid) tot += ab.heal;
    }
    return tot;
  }

  incomingShieldFor(hid: HeroId): number {
    const heroes = this.state.heroes();
    let tot = 0;

    for (const h of heroes) {
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab || !ab.shield) continue;

      if (ab.shieldAll) {
        tot += ab.shield;
        continue;
      }
      if (ab.shTgt) {
        if (h.shTgtIdx === null) continue;
        const tgt = heroes[h.shTgtIdx];
        if (tgt?.id === hid) tot += ab.shield;
        continue;
      }
      if (h.id === hid) tot += ab.shield;
    }
    return tot;
  }

  incomingRfeForEnemy(ei: number): number {
    let t = 0;
    for (const h of this.state.heroes()) {
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab?.rfe) continue;
      if (ab.rfeAll) {
        t += ab.rfe;
        continue;
      }
      const hTgt = h.lockedTarget !== undefined && h.lockedTarget !== null ? h.lockedTarget : null;
      if (hTgt === ei) t += ab.rfe;
    }
    return t;
  }

  incomingDotDetailForEnemy(ei: number): { dot: number; dT: number } {
    let dot = 0;
    let dt = 0;
    for (const h of this.state.heroes()) {
      if (h.currentHp <= 0 || h.roll === null) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab?.dot) continue;
      if (ab.blastAll) {
        dot += ab.dot;
        dt = Math.max(dt, ab.dT || 0);
        continue;
      }
      const hTgt = h.lockedTarget !== undefined && h.lockedTarget !== null ? h.lockedTarget : null;
      if (hTgt !== ei) continue;
      dot += ab.dot;
      dt = Math.max(dt, ab.dT || 0);
    }
    return { dot, dT: dt };
  }
}
