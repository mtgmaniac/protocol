import { Component, ChangeDetectionStrategy, input, computed } from '@angular/core';

@Component({
  selector: 'app-hp-bar',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="hp-lbl" [style.color]="labelColor()">HP {{ current() }}/{{ max() }}</div>
    <div class="hp-bar">
      <div class="hp-fill" [class]="fillClass()" [style.width]="widthPct()"></div>
    </div>
  `,
  styles: [`
    .hp-lbl { font-family: 'Share Tech Mono', monospace; font-size: 9px; font-weight: 800; margin-bottom: 2px; margin-top: 5px; }
    .hp-bar { width: 100%; height: 4px; background: rgba(255,255,255,.07); border-radius: 2px; overflow: hidden; margin-bottom: 2px; }
    .hp-fill { height: 100%; border-radius: 2px; transition: width 0.3s; }
    .hp-fill-g { background: #1d9e75; }
    .hp-fill-y { background: #e8b84a; }
    .hp-fill-r { background: #d84a2a; }
  `],
})
export class HpBarComponent {
  current = input.required<number>();
  max = input.required<number>();

  widthPct = computed(() => {
    const m = this.max();
    if (m <= 0) return '0%';
    return Math.max(0, Math.min(100, Math.round((this.current() / m) * 100))) + '%';
  });

  fillClass = computed(() => {
    const m = this.max();
    if (m <= 0) return 'hp-fill hp-fill-r';
    const pct = this.current() / m;
    if (pct <= 0.25) return 'hp-fill hp-fill-r';
    if (pct <= 0.5) return 'hp-fill hp-fill-y';
    return 'hp-fill hp-fill-g';
  });

  labelColor = computed(() => {
    const m = this.max();
    if (m <= 0) return 'var(--hr)';
    const pct = this.current() / m;
    if (pct <= 0.25) return 'var(--hr)';
    if (pct <= 0.5) return 'var(--cell)';
    return 'var(--muted)';
  });
}
