import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { LogService } from '../../services/log.service';

@Component({
  selector: 'app-battle-log',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="log-wrap" [class.log-collapsed]="!state.logOpen()">
      <div class="log-hdr">
        <div class="log-left">
          <button class="log-toggle" (click)="logService.toggleOpen()">{{ state.logOpen() ? '−' : '+' }}</button>
          <span class="log-title">BATTLE LOG</span>
        </div>
        <div class="log-mode">
          <button [class.active]="state.logMode() === 'min'" (click)="logService.setMode('min')">MAJOR</button>
          <button [class.active]="state.logMode() === 'all'" (click)="logService.setMode('all')">ALL</button>
        </div>
      </div>
      @if (state.logOpen()) {
        <div class="battle-log">
          @for (entry of logService.getFilteredLog(); track $index) {
            <div class="le" [class]="entry.cls">{{ entry.msg }}</div>
          }
        </div>
      }
    </div>
  `,
  styles: [`
    .log-wrap { background: var(--bg2); border: 1px solid var(--border); border-radius: 4px; margin-top: 8px; margin-bottom: 8px; overflow: hidden; }
    .log-hdr { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; border-bottom: 1px solid rgba(255,255,255,.06); }
    .log-left { display: flex; align-items: center; gap: 8px; min-width: 0; }
    .log-toggle {
      background: transparent; border: 1px solid var(--border2); color: var(--muted); border-radius: 3px;
      width: 20px; height: 20px; cursor: pointer; font-family: 'Share Tech Mono', monospace; font-size: 11px;
      display: flex; align-items: center; justify-content: center;
    }
    .log-toggle:hover { border-color: var(--strike); color: var(--strike); }
    .log-title { font-family: 'Share Tech Mono', monospace; font-size: 9px; letter-spacing: 2px; color: var(--muted); white-space: nowrap; }
    .log-mode { display: flex; gap: 6px; align-items: center; }
    .log-mode button {
      background: transparent; border: 1px solid rgba(255,255,255,.08); color: var(--muted); border-radius: 3px;
      padding: 2px 6px; cursor: pointer; font-family: 'Share Tech Mono', monospace; font-size: 9px;
    }
    .log-mode button.active { border-color: var(--strike); color: var(--strike); background: rgba(46,125,212,.08); }
    .battle-log { padding: 6px 10px; font-family: 'Share Tech Mono', monospace; font-size: 9px; max-height: 80px; overflow-y: auto; }
    .le { color: var(--muted); margin-bottom: 2px; line-height: 1.5; }
    .le.pl { color: var(--strike); }
    .le.en { color: var(--overload); }
    .le.sy { color: var(--cell); }
    .le.bl { color: var(--build); }
    .le.vi { color: var(--hg); font-weight: 700; }
    .le.de { color: var(--hr); font-weight: 700; }
  `],
})
export class BattleLogComponent {
  state = inject(GameStateService);
  logService = inject(LogService);
}
