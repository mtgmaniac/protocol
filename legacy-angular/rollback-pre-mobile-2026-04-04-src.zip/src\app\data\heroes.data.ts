import { HeroDefinition } from '../models/hero.interface';
import { HeroId, Zone } from '../models/types';

// ── PER-HERO ZONE BRACKETS ──────────────────────────────────────────────────
export const HERO_ZONES: Record<HeroId, [number, number, Zone][]> = {
  pulse:[[1,3,'recharge'],[4,9,'strike'],[10,15,'surge'],[16,19,'crit'],[20,20,'overload']],
  combat:[[1,4,'recharge'],[5,10,'strike'],[11,15,'surge'],[16,19,'crit'],[20,20,'overload']],
  shield:[[1,6,'recharge'],[7,12,'strike'],[13,16,'surge'],[17,19,'crit'],[20,20,'overload']],
  medic:[[1,4,'recharge'],[5,11,'strike'],[12,16,'surge'],[17,19,'crit'],[20,20,'overload']],
  engineer:[[1,4,'recharge'],[5,10,'strike'],[11,15,'surge'],[16,19,'crit'],[20,20,'overload']],
  ghost:[[1,2,'recharge'],[3,8,'strike'],[9,13,'surge'],[14,19,'crit'],[20,20,'overload']],
};

// ── HERO DEFINITIONS ─────────────────────────────────────────────────────────
export const ALL_HEROES: HeroDefinition[] = [
  {id:'pulse',name:'Pulse Tech',cls:'ENERGY WIELDER',hp:35,sk:'pulse',abilities:[
    {zone:'recharge',range:[1,3],name:'Static Ping',eff:'3 dmg',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:0,heal:0},
    {zone:'strike',range:[4,9],name:'Arc Burst',eff:'5 dmg',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:0},
    {zone:'surge',range:[10,15],name:'Plasma Lance',eff:'8 dmg, +1 DoT 2t',dmg:7,dMin:7,dMax:7,dot:1,dT:2,rfe:0,heal:0},
    {zone:'crit',range:[16,19],name:'Ion Storm',eff:'11 dmg, +2 DoT 2t',dmg:10,dMin:10,dMax:10,dot:2,dT:2,rfe:0,heal:0},
    {zone:'overload',range:[20,20],name:'Ion Storm+',eff:'13 dmg, +2 DoT 3t',dmg:12,dMin:12,dMax:12,dot:2,dT:3,rfe:0,heal:0}
  ],evolutions:[
    {name:'Cryo Specialist',focus:'Cold control / roll debuff',hp:50,abilities:[
    {zone:'recharge',range:[1,5],name:'Frost Shard',eff:'5 dmg, -1 roll debuff',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:1,rfT:1,heal:0}
    ]},
    {name:'Cryo Specialist',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Cryo Shell',eff:'8 shield 2t (ally)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:8,shT:2,shTgt:true}
    ]},
    {name:'Cryo Specialist',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Ice Lance',eff:'12 dmg, -3 roll debuff (2t)',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:3,rfT:2,heal:0}
    ]},
    {name:'Cryo Specialist',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Cryogenic Lock',eff:'-5 roll debuff (3t)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:5,rfT:3,heal:0}
    ]},
    {name:'Cryo Specialist',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Cryogenic Lock+',eff:'-7 roll debuff (3t)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:6,rfT:3,heal:0}
    ]},
    {name:'Pyro Specialist',focus:'Raw damage / DoT burst',hp:45,abilities:[
    {zone:'recharge',range:[1,5],name:'Ignition Flash',eff:'5 dmg, 1 DoT 1t',dmg:5,dMin:5,dMax:5,dot:1,dT:1,rfe:0,heal:0}
    ]},
    {name:'Pyro Specialist',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Plasma Burst',eff:'10 dmg',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Pyro Specialist',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Meltdown',eff:'5 DoT 3t',dmg:0,dMin:0,dMax:0,dot:5,dT:3,rfe:0,heal:0}
    ]},
    {name:'Pyro Specialist',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Magma Whip',eff:'20 dmg',dmg:18,dMin:18,dMax:18,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Pyro Specialist',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Magma Whip+',eff:'25 dmg',dmg:23,dMin:23,dMax:23,dot:0,dT:0,rfe:0,heal:0}
    ]}
  ]},
  {id:'combat',name:'Combat Unit',cls:'ASSAULT SPEC.',hp:50,sk:'combat',abilities:[
    {zone:'recharge',range:[1,4],name:'Test Shot',eff:'2 dmg',dmg:2,dMin:2,dMax:2,dot:0,dT:0,rfe:0,heal:0},
    {zone:'strike',range:[5,10],name:'Suppression Fire',eff:'2 dmg, -2 enemy roll',dmg:2,dMin:2,dMax:2,dot:0,dT:0,rfe:2,rfT:1,heal:0},
    {zone:'surge',range:[11,15],name:'Rail Strike',eff:'5 dmg, -3 enemy roll',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:3,rfT:1,heal:0},
    {zone:'crit',range:[16,19],name:'Overdrive',eff:'12 dmg',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:0,heal:0},
    {zone:'overload',range:[20,20],name:'Overdrive+',eff:'17 dmg',dmg:15,dMin:15,dMax:15,dot:0,dT:0,rfe:0,heal:0}
  ],evolutions:[
    {name:'Bladecore',focus:'Multi-hit / rapid attacks',hp:65,abilities:[
    {zone:'recharge',range:[1,5],name:'Target Paint',eff:'3 dmg',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Bladecore',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Rapid Strike',eff:'5 dmg, multi-hit',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:0,multiHit:true}
    ]},
    {name:'Bladecore',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Blade Rush',eff:'9 dmg, multi-hit, -1 roll debuff',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:1,rfT:1,heal:0,multiHit:true}
    ]},
    {name:'Bladecore',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Shred',eff:'14-16 dmg, pierce',dmg:14,dMin:13,dMax:14,dot:0,dT:0,rfe:0,heal:0,ignSh:true}
    ]},
    {name:'Bladecore',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Decimator',eff:'19 dmg, multi-hit, pierce',dmg:17,dMin:17,dMax:17,dot:0,dT:0,rfe:0,heal:0,ignSh:true,multiHit:true}
    ]},
    {name:'Ravager',focus:'Bleed / damage-over-time',hp:60,abilities:[
    {zone:'recharge',range:[1,5],name:'Mark Target',eff:'2 dmg, 1 DoT 1t',dmg:2,dMin:2,dMax:2,dot:1,dT:1,rfe:0,heal:0}
    ]},
    {name:'Ravager',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Lacerate',eff:'6 dmg, 2 DoT 2t',dmg:5,dMin:5,dMax:5,dot:2,dT:2,rfe:0,heal:0}
    ]},
    {name:'Ravager',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Deep Wound',eff:'10 dmg, 3 DoT 3t',dmg:9,dMin:9,dMax:9,dot:3,dT:3,rfe:0,heal:0}
    ]},
    {name:'Ravager',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Hemorrhage',eff:'15 dmg, 4 DoT 3t',dmg:14,dMin:14,dMax:14,dot:4,dT:3,rfe:0,heal:0}
    ]},
    {name:'Ravager',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Hemorrhage+',eff:'23 dmg, 5 DoT 3t',dmg:21,dMin:21,dMax:21,dot:5,dT:3,rfe:0,heal:0}
    ]}
  ]},
  {id:'shield',name:'Aegis Disruptor',cls:'DISRUPTOR',hp:55,sk:'shield',abilities:[
    {zone:'recharge',range:[1,6],name:'Threat Protocol',eff:'-2 roll debuff (2t)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:2,rfT:2,heal:0,rfeOnly:true},
    {zone:'strike',range:[7,12],name:'Enforce',eff:'6 shield any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:6,shT:1,shTgt:true},
    {zone:'surge',range:[13,16],name:'Deflector Field',eff:'7 shield 2t any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:7,shT:2,shTgt:true},
    {zone:'crit',range:[17,19],name:'Demolish',eff:'9 dmg, -3 enemy roll 2t',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:3,rfT:2,heal:0},
    {zone:'overload',range:[20,20],name:'Demolish+',eff:'11 dmg, -4 enemy roll 2t',dmg:10,dMin:10,dMax:10,dot:0,dT:0,rfe:4,rfT:2,heal:0}
  ],evolutions:[
    {name:'Bulwark',focus:'Fortress shields / team cover',hp:80,abilities:[
    {zone:'recharge',range:[1,5],name:'Fortify',eff:'6 shield self',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:6,shT:2}
    ]},
    {name:'Bulwark',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Cover Fire',eff:'3 dmg, 4 shield ally',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:0,heal:0,shield:4,shT:2,shTgt:true}
    ]},
    {name:'Bulwark',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Iron Wall',eff:'12 shield all 2t',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:12,shT:2,shieldAll:true}
    ]},
    {name:'Bulwark',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Bastion Protocol',eff:'5 dmg, 8 shield (ally), -2 roll debuff (2t)',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:2,rfT:2,heal:0,shield:8,shT:2,shTgt:true}
    ]},
    {name:'Bulwark',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Invincible',eff:'8 dmg, 14 shield all',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:3,rfT:2,heal:0,shield:14,shT:2,shieldAll:true}
    ]},
    {name:'Sentinel',focus:'Counter-attacks and taunt',hp:75,abilities:[
    {zone:'recharge',range:[1,5],name:'Taunt',eff:'Force all to target self',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,taunt:true}
    ]},
    {name:'Sentinel',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Retaliate',eff:'6-8 dmg',dmg:6,dMin:5,dMax:7,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Sentinel',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Counter Protocol',eff:'9 dmg, -2 roll debuff',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:2,rfT:2,heal:0}
    ]},
    {name:'Sentinel',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Repulsion Field',eff:'11 dmg, -3 roll debuff (2t)',dmg:10,dMin:10,dMax:10,dot:0,dT:0,rfe:3,rfT:2,heal:0}
    ]},
    {name:'Sentinel',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Repulsion Field+',eff:'15 dmg, -4 roll debuff (2t)',dmg:14,dMin:14,dMax:14,dot:0,dT:0,rfe:4,rfT:2,heal:0}
    ]}
  ]},
  {id:'medic',name:'Systems Medic',cls:'FIELD SUPPORT',hp:40,sk:'medic',abilities:[
    {zone:'recharge',range:[1,4],name:'Diagnostic Pulse',eff:'+3 roll buff (ally)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,rfm:3,rfmT:1,rfmTgt:true},
    {zone:'strike',range:[5,11],name:'Infusion',eff:'Heal 7 HP any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:6,healTgt:true},
    {zone:'surge',range:[12,16],name:'Shock Therapy',eff:'Revive ally (50%)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,revive:true},
    {zone:'crit',range:[17,19],name:'Neural Override',eff:'8 dmg, heal 6 HP',dmg:7,dMin:7,dMax:7,dot:0,dT:0,rfe:0,heal:5},
    {zone:'overload',range:[20,20],name:'Neural Override+',eff:'12 dmg, heal 8 HP',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:0,heal:8}
  ],evolutions:[
    {name:'Combat Medic',focus:'Heal while dealing damage',hp:60,abilities:[
    {zone:'recharge',range:[1,5],name:'Triage',eff:'Heal 6 HP any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:5,healTgt:true}
    ]},
    {name:'Combat Medic',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Bio-Shock',eff:'5 dmg, heal 4 HP ally',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:4,healLowest:true}
    ]},
    {name:'Combat Medic',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Trauma Protocol',eff:'8 dmg, heal 6 HP ally',dmg:7,dMin:7,dMax:7,dot:0,dT:0,rfe:0,heal:5,healTgt:true}
    ]},
    {name:'Combat Medic',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Surge Heal',eff:'10 dmg, heal 9 HP ally',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:0,heal:8,healTgt:true}
    ]},
    {name:'Combat Medic',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Mass Revival',eff:'12 dmg, heal all 6 HP',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:0,heal:5,healAll:true}
    ]},
    {name:'Techno Shaman',focus:'Team-wide buffs and revival',hp:70,abilities:[
    {zone:'recharge',range:[1,5],name:'System Boost',eff:'+2 roll buff next 1t',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,rfm:2,rfmT:1}
    ]},
    {name:'Techno Shaman',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Overclock',eff:'Heal 4 HP + 3 shield all',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:4,healAll:true,shield:3,shT:2,shieldAll:true}
    ]},
    {name:'Techno Shaman',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Emergency Protocol',eff:'Heal lowest 10 HP',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:9,healLowest:true}
    ]},
    {name:'Techno Shaman',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Adrenaline Surge',eff:'6 dmg, heal all 6 HP',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:5,healAll:true}
    ]},
    {name:'Techno Shaman',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Resurrection',eff:'Revive ally 50%, heal all 5 HP',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:5,healAll:true,revive:true}
    ]}
  ]},
  {id:'engineer',name:'Field Engineer',cls:'SUPPORT TECH',hp:45,sk:'engineer',abilities:[
    {zone:'recharge',range:[1,4],name:'Field Patch',eff:'Heal 4 HP any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:4,healTgt:true},
    {zone:'strike',range:[5,10],name:'Barrier Deploy',eff:'5 shield any ally',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,shield:5,shT:1,shTgt:true},
    {zone:'surge',range:[11,15],name:'Precision Shot',eff:'9 dmg',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:0,heal:0},
    {zone:'crit',range:[16,19],name:'Missile Volley',eff:'7 dmg to all enemies',dmg:6,dMin:6,dMax:6,dot:0,dT:0,rfe:0,heal:0,blastAll:true},
    {zone:'overload',range:[20,20],name:'Missile Volley+',eff:'10 dmg to all enemies',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:0,heal:0,blastAll:true}
  ],evolutions:[
    {name:'Overclocked',focus:'Burst damage / AoE',hp:60,abilities:[
    {zone:'recharge',range:[1,5],name:'Bias Charge',eff:'+1 squad roll 1t',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,rfm:1,rfmT:1}
    ]},
    {name:'Overclocked',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Chain Shot',eff:'5 dmg',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Overclocked',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Overclock Burst',eff:'9 dmg',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Overclocked',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Cascade',eff:'8 dmg (all enemies)',dmg:8,dMin:8,dMax:8,dot:0,dT:0,rfe:0,heal:0,blastAll:true}
    ]},
    {name:'Overclocked',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Meltdown Protocol',eff:'18 dmg, 3 DoT 2t',dmg:18,dMin:18,dMax:18,dot:3,dT:2,rfe:0,heal:0}
    ]},
    {name:'Wraith Engineer',focus:'Stealth deployments',hp:55,abilities:[
    {zone:'recharge',range:[1,5],name:'Stealth',eff:'Cloak self (80% dodge next hit)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,cloak:true}
    ]},
    {name:'Wraith Engineer',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'EMP Pulse',eff:'3 dmg, -2 roll debuff all (1t)',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:2,rfT:1,heal:0,rfeAll:true}
    ]},
    {name:'Wraith Engineer',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Phantom Shield',eff:'5 dmg, 7 shield self',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:0,heal:0,shield:7,shT:2}
    ]},
    {name:'Wraith Engineer',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Ghost Volley',eff:'14 dmg to all enemies, pierce',dmg:13,dMin:13,dMax:13,dot:0,dT:0,rfe:0,heal:0,ignSh:true,blastAll:true}
    ]},
    {name:'Wraith Engineer',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Total Blackout',eff:'12 dmg to all enemies, -4 roll debuff all (2t)',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:4,rfT:2,heal:0,blastAll:true,rfeAll:true}
    ]}
  ]},
  {id:'ghost',name:'Ghost Operative',cls:'INFILTRATOR',hp:35,sk:'ghost',abilities:[
    {zone:'recharge',range:[1,2],name:'Probe Strike',eff:'3 dmg',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:0,heal:0},
    {zone:'strike',range:[3,8],name:'Cloak Protocol',eff:'Cloak self (80% dodge next hit)',dmg:0,dMin:0,dMax:0,dot:0,dT:0,rfe:0,heal:0,cloak:true},
    {zone:'surge',range:[9,13],name:'System Breach',eff:'8 damage, 3 DoT 1t',dmg:7,dMin:7,dMax:7,dot:3,dT:1,rfe:0,heal:0},
    {zone:'crit',range:[14,19],name:'Phase Blade',eff:'12 dmg ignores shield',dmg:11,dMin:11,dMax:11,dot:0,dT:0,rfe:0,heal:0,ignSh:true},
    {zone:'overload',range:[20,20],name:'Phase Blade+',eff:'15 dmg ignores shield',dmg:14,dMin:14,dMax:14,dot:0,dT:0,rfe:0,heal:0,ignSh:true}
  ],evolutions:[
    {name:'Shadow Operative',focus:'Stealth, burst, evasion',hp:50,abilities:[
    {zone:'recharge',range:[1,5],name:'Ghost Step',eff:'3 dmg, cloak (80% dodge next hit)',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:0,heal:0,cloak:true}
    ]},
    {name:'Shadow Operative',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Shadow Strike',eff:'10 dmg',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:0,heal:0}
    ]},
    {name:'Shadow Operative',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Vanishing Act',eff:'10 dmg, cloak (80%), -2 roll debuff',dmg:9,dMin:9,dMax:9,dot:0,dT:0,rfe:2,rfT:2,heal:0,cloak:true}
    ]},
    {name:'Shadow Operative',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Phantom Blade',eff:'14 dmg pierce, cloak (80%)',dmg:13,dMin:13,dMax:13,dot:0,dT:0,rfe:0,heal:0,ignSh:true,cloak:true}
    ]},
    {name:'Shadow Operative',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Death from Shadow',eff:'19 dmg pierce',dmg:17,dMin:17,dMax:17,dot:0,dT:0,rfe:0,heal:0,ignSh:true}
    ]},
    {name:'Wraith',focus:'Debuffs and elimination',hp:55,abilities:[
    {zone:'recharge',range:[1,5],name:'Scan Weakness',eff:'3 dmg, -1 roll debuff (2t)',dmg:3,dMin:3,dMax:3,dot:0,dT:0,rfe:1,rfT:2,heal:0}
    ]},
    {name:'Wraith',focus:'',hp:0,abilities:[
    {zone:'strike',range:[6,10],name:'Neural Hack',eff:'5 dmg, -3 roll debuff (2t)',dmg:5,dMin:5,dMax:5,dot:0,dT:0,rfe:3,rfT:2,heal:0}
    ]},
    {name:'Wraith',focus:'',hp:0,abilities:[
    {zone:'surge',range:[11,15],name:'Assassinate',eff:'15 dmg pierce',dmg:14,dMin:14,dMax:14,dot:0,dT:0,rfe:0,heal:0,ignSh:true}
    ]},
    {name:'Wraith',focus:'',hp:0,abilities:[
    {zone:'crit',range:[16,19],name:'Wraith Blade',eff:'13 dmg, 3 DoT (2t), -2 roll debuff (2t)',dmg:12,dMin:12,dMax:12,dot:3,dT:2,rfe:2,rfT:2,heal:0}
    ]},
    {name:'Wraith',focus:'',hp:0,abilities:[
    {zone:'overload',range:[20,20],name:'Execution Protocol',eff:'19 dmg pierce, -4 roll debuff (2t)',dmg:17,dMin:17,dMax:17,dot:0,dT:0,rfe:4,rfT:2,heal:0,ignSh:true}
    ]}
  ]},
];
