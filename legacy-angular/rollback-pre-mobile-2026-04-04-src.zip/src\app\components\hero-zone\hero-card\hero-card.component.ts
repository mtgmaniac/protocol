import { Component, ChangeDetectionStrategy, input, output, computed, inject } from '@angular/core';
import { HeroState } from '../../../models/hero.interface';
import { HeroAbility } from '../../../models/ability.interface';
import { DiceService } from '../../../services/dice.service';
import { GameStateService } from '../../../services/game-state.service';
import { TargetingService } from '../../../services/targeting.service';
import { HpBarComponent } from '../../shared/hp-bar/hp-bar.component';
import { PortraitFrameComponent } from '../../shared/portrait-frame/portrait-frame.component';
import { AbilityRowComponent } from '../../shared/ability-row/ability-row.component';
import { BadgeZoneComponent } from '../../shared/badge-zone/badge-zone.component';
import { heroPortraitSvg } from '../../../data/sprites.data';

@Component({
  selector: 'app-hero-card',
  standalone: true,
  imports: [HpBarComponent, PortraitFrameComponent, AbilityRowComponent, BadgeZoneComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="hcard" [class.hcard-interactive]="hero().currentHp > 0"
         [class.is-dead]="hero().currentHp <= 0"
         [class.hcard-selected]="isSelected()"
         [class.selectable-ally-pick]="pickMode() === 'heal' || pickMode() === 'shield' || pickMode() === 'rollBuff'"
         [class.selectable-revive-pick]="pickMode() === 'revive'"
         (click)="onClick()">
      <!-- Ability panel -->
      <div class="ap">
        <div class="ap-title">ABILITIES</div>
        @for (ab of hero().abilities; track ab.name) {
          <app-ability-row [ability]="ab" [zone]="ab.zone" [rangeStr]="getRangeStr(ab)" [isCurrent]="isCurrentAbility(ab)" />
        }
      </div>
      <!-- Bottom section: info + portrait -->
      <div class="hbot">
        <div class="info-col">
          <div>
            <div class="hname">{{ hero().name }}
              @if (hero().tier === 2) { <span class="t1">T2</span> }
            </div>
            <!-- Target line -->
            <div class="hero-target-line">
              <span class="tgt-ready-chk"
                    [class.tgt-ready-chk--done]="targetLine().checkDone"
                    [attr.title]="targetLine().checkDone ? 'Target set' : 'Assign target'"
                    aria-hidden="true">
                @if (targetLine().checkDone) {
                  <span class="tgt-ready-mark">&#x2713;</span>
                }
              </span>
              <span class="hero-target-text">
                @for (seg of targetLine().segments; track $index) {
                  @switch (seg.t) {
                    @case ('plain') { <span>{{ seg.text }}</span> }
                    @case ('muted') { <span class="tgt-muted">{{ seg.text }}</span> }
                    @case ('all') { <span class="tgt-all">{{ seg.text }}</span> }
                    @case ('self') { <span class="tgt-self">{{ seg.text }}</span> }
                    @case ('enemy') { <span class="tgt-enemy">{{ seg.text }}</span> }
                    @case ('ally') { <span class="tgt-ally">{{ seg.text }}</span> }
                  }
                }
              </span>
            </div>
          </div>
          <div>
            <app-hp-bar [current]="hero().currentHp" [max]="hero().maxHp" />
            <!-- XP bar for tier 1 -->
            @if (hero().tier === 1) {
              <div class="xp-bar"><div class="xp-f" [style.width]="xpWidth()"></div></div>
            }
            <app-badge-zone kind="hero" [index]="index()" />
          </div>
        </div>
        <div class="sprite">
          <app-portrait-frame [svg]="heroSvg()" [isCloaked]="hero().cloaked" />
        </div>
      </div>
    </div>
  `,
  styles: [`
    .hcard {
      width: 240px;
      border-radius: 4px;
      background: #0d1520;
      border: 1px solid #1e3a5f;
    }
    .hcard-interactive {
      cursor: pointer;
      z-index: 2;
    }
    .is-dead {
      opacity: .28;
    }
    .hcard-selected {
      box-shadow: 0 0 0 2px rgba(46,125,212,.65);
    }
    .selectable-ally-pick {
      cursor: pointer;
      box-shadow: 0 0 0 2px rgba(46,196,106,.4);
    }
    .selectable-revive-pick {
      cursor: pointer;
      box-shadow: 0 0 0 2px rgba(182,123,255,.45);
    }
    .ap {
      background: #060e18;
      padding: 5px 8px;
      border-bottom: 1px solid #1e3a5f;
    }
    .ap-title {
      font-size: 7px;
      letter-spacing: 2px;
      color: #4a6a8a;
    }
    .hbot {
      padding: 6px 7px;
      display: flex;
      gap: 6px;
    }
    .info-col {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .hname {
      font-size: 11px;
      font-weight: 800;
      color: #fff;
    }
    .t1 {
      font-size: 6px;
      padding: 0 2px;
      border-radius: 2px;
      background: #1e3a5f;
      color: #2e7dd4;
      border: 1px solid #2a4f7a;
    }
    .hero-target-line {
      font-size: 8px;
      line-height: 1.35;
      color: #6f95b3;
      margin-top: 4px;
      display: flex;
      align-items: flex-start;
      gap: 5px;
      word-break: break-word;
    }
    .hero-target-text { flex: 1; min-width: 0; }
    .tgt-muted { color: #4a6a8a; }
    .tgt-self { color: #7dcea0; font-weight: 700; }
    .tgt-ally { color: #2ec46a; font-weight: 700; }
    .tgt-enemy { color: #e07060; font-weight: 700; }
    .tgt-all { color: #c8ddf0; font-weight: 700; }
    .tgt-ready-chk {
      width: 11px;
      height: 11px;
      border: 1px solid rgba(46,196,106,.28);
      border-radius: 2px;
      background: rgba(8,20,14,.55);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .tgt-ready-chk--done {
      border-color: rgba(52,210,120,.65);
      background: rgba(46,196,106,.14);
    }
    .tgt-ready-mark {
      color: #3ecf6e;
      font-size: 9px;
      font-weight: 800;
    }
    .sprite {
      flex-shrink: 0;
      display: flex;
      align-items: flex-end;
    }
    .xp-bar {
      height: 2px;
      background: rgba(255,255,255,.06);
      border-radius: 1px;
      overflow: hidden;
      margin-bottom: 3px;
      margin-top: 2px;
    }
    .xp-f {
      height: 100%;
      background: #e8b84a;
      transition: width .4s;
    }
  `],
})
export class HeroCardComponent {
  private dice = inject(DiceService);
  private state = inject(GameStateService);
  private targeting = inject(TargetingService);

  hero = input.required<HeroState>();
  index = input.required<number>();
  isSelected = input<boolean>(false);
  pickMode = input<string | null>(null);
  hideRoll = input<boolean>(false);

  heroClicked = output<void>();
  allyPickClicked = output<void>();

  heroSvg = computed(() => heroPortraitSvg(this.hero().id));

  targetLine = computed(() => {
    this.state.heroes();
    this.state.enemies();
    this.hero();
    return this.targeting.getHeroTargetLineView(this.index());
  });

  xpWidth = computed(() => {
    const pct = Math.min(100, (this.hero().hrs / 18) * 100);
    return pct + '%';
  });

  isCurrentAbility(ab: HeroAbility): boolean {
    const h = this.hero();
    const er = this.dice.effRoll(h);
    if (er === null) return false;
    return er >= ab.range[0] && er <= ab.range[1];
  }

  getRangeStr(ab: HeroAbility): string {
    return ab.range[0] === ab.range[1] ? `${ab.range[0]}` : `${ab.range[0]}-${ab.range[1]}`;
  }

  onClick(): void {
    const pm = this.pickMode();
    if (pm === 'heal' || pm === 'shield' || pm === 'rollBuff' || pm === 'revive') {
      this.allyPickClicked.emit();
    } else {
      this.heroClicked.emit();
    }
  }
}
