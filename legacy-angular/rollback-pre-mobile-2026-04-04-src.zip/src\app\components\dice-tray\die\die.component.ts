import { Component, ChangeDetectionStrategy, input, output, computed, ElementRef, viewChild } from '@angular/core';

@Component({
  selector: 'app-die',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="die-wrap" #dieWrap [class.die-clickable]="clickable()" (click)="onDieClick()">
      <svg viewBox="0 0 64 64" fill="none">
        <polygon [attr.points]="'32,4 60,20 60,44 32,60 4,44 4,20'" [attr.stroke]="activeColor()" stroke-width="1.5" [attr.fill]="activeColor() + '18'"/>
        <polygon points="32,4 60,20 32,28" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '0a'"/>
        <polygon points="32,28 60,20 60,44" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '12'"/>
        <polygon points="32,28 60,44 32,60" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '0a'"/>
        <polygon points="32,28 32,60 4,44" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '12'"/>
        <polygon points="32,28 4,44 4,20" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '0a'"/>
        <polygon points="32,28 4,20 32,4" [attr.stroke]="activeColor()" stroke-width="0.5" [attr.fill]="activeColor() + '12'"/>
      </svg>
      <div class="die-n" [style.color]="activeColor()" [style.font-size]="fontSize()">{{ activeDisplay() }}</div>
    </div>
  `,
  styles: [`
    :host { display: contents; }
    .die-wrap { width: 40px; height: 40px; position: relative; flex-shrink: 0; }
    .die-clickable { cursor: pointer; }
    .die-clickable:hover { filter: brightness(1.08); }
    .die-wrap svg { width: 100%; height: 100%; }
    .die-n {
      position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      font-family: 'Share Tech Mono', monospace; font-size: 12px; font-weight: 700;
      pointer-events: none;
    }
    @keyframes dieBounce {
      0% { transform: scale(0.5) rotate(-20deg); opacity: 0.4; }
      60% { transform: scale(1.15) rotate(3deg); }
      100% { transform: scale(1) rotate(0); opacity: 1; }
    }
  `],
})
export class DieComponent {
  roll = input<number | null>(null);
  color = input('#2a3a50');
  clickable = input(false);
  displayText = input<string | null>(null);

  /** Animation overrides — set by parent during roll animation */
  animDisplay = input<string | null>(null);
  animColor = input<string | null>(null);
  animBounce = input(false);

  dieClicked = output<void>();

  dieWrap = viewChild<ElementRef<HTMLElement>>('dieWrap');

  displayValue = computed(() => {
    if (this.displayText()) return this.displayText()!;
    const r = this.roll();
    return r !== null ? String(r) : '--';
  });

  /** During animation, override display; otherwise use normal */
  activeDisplay = computed(() => this.animDisplay() ?? this.displayValue());

  /** During animation, override color; otherwise use normal */
  activeColor = computed(() => this.animColor() ?? this.color());

  fontSize = computed(() => {
    const val = this.activeDisplay();
    return val.length > 3 ? '9px' : '12px';
  });

  /** Trigger CSS bounce animation on the die-wrap element */
  triggerBounce(): void {
    const el = this.dieWrap()?.nativeElement;
    if (!el) return;
    el.style.animation = 'none';
    void el.offsetWidth; // force reflow
    el.style.animation = 'dieBounce .35s ease';
  }

  onDieClick(): void {
    if (this.clickable()) {
      this.dieClicked.emit();
    }
  }
}
