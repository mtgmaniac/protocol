import { EnemyAbility } from './ability.interface';
import { AIType, EnemyType, HeroId, Zone } from './types';

export interface EnemyDefinition {
  name: string;
  hp: number;
  dMin: number;
  dMax: number;
  type: EnemyType;
  ai: AIType;
  p2dMin?: number;
  p2dMax?: number;
  pThr?: number;
}

export interface EnemyState extends EnemyDefinition {
  id: number;
  currentHp: number;
  maxHp: number;
  dead: boolean;
  rfe: number;
  rfT: number;
  p2: boolean;
  dot: number;
  dT: number;
  shield: number;
  shT: number;
  targeting: HeroId | null;
  dumbStickyId: HeroId | null;
  preRoll: number;
  effRoll: number;
  curZone: Zone;
  plan: EnemyAbility | null;
  dmgScale: number;
}

export function createEnemyState(def: EnemyDefinition, id: number): EnemyState {
  return {
    ...def,
    id,
    currentHp: def.hp,
    maxHp: def.hp,
    dead: false,
    rfe: 0,
    rfT: 0,
    p2: false,
    dot: 0,
    dT: 0,
    shield: 0,
    shT: 0,
    targeting: null,
    dumbStickyId: null,
    preRoll: 0,
    effRoll: 0,
    curZone: 'recharge',
    plan: null,
    dmgScale: 1,
  };
}
