import { EnemyAbilitySuite } from '../models/ability.interface';
import { EnemyDefinition } from '../models/enemy.interface';
import { EnemyType } from '../models/types';

// ── ENEMY ABILITY SUITES ─────────────────────────────────────────────────────
export const ENEMY_ABILITIES: Record<EnemyType, EnemyAbilitySuite> = {
  scrap:{
    recharge:{name:'Power Down',eff:'—',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:0},
    strike:{name:'Stab',eff:'Moderate damage',dmg:7,dot:0,dT:0,heal:0,rfe:0,shield:0},
    surge:{name:'Overcharge',eff:'Heavy damage + 1 DoT 1t',dmg:10,dot:1,dT:1,heal:0,rfe:0,shield:0},
    crit:{name:'Overcharge+',eff:'Very heavy + 2 DoT 2t',dmg:15,dot:2,dT:2,heal:0,rfe:0,shield:0},
    overload:{name:'Detonator',eff:'Massive + 3 DoT 2t',dmg:20,dot:3,dT:2,heal:0,rfe:0,shield:0},
  },
  rust:{
    recharge:{name:'Signal Jam',eff:'— roll debuff on squad',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:1,rfmT:2},
    strike:{name:'Sparking Cut',eff:'Damage + roll debuff',dmg:6,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:1,rfmT:2},
    surge:{name:'Disrupt Pulse',eff:'Damage + roll debuff',dmg:9,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:1,rfmT:2},
    crit:{name:'EMP Spike',eff:'Heavy hit + roll debuff',dmg:12,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:2,rfmT:2},
    overload:{name:'Total Jam',eff:'Big hit + heavy roll debuff',dmg:14,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:3,rfmT:3},
  },
  patrol:{
    recharge:{name:'Regroup',eff:'+5 shield self',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:6,shT:2},
    strike:{name:'Assault',eff:'Standard damage',dmg:15,dot:0,dT:0,heal:0,rfe:0,shield:0},
    surge:{name:'Heavy Barrage',eff:'Heavy damage',dmg:18,dot:0,dT:0,heal:0,rfe:0,shield:0},
    crit:{name:'Devastate',eff:'Heavy damage + roll debuff',dmg:21,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:1,rfmT:2},
    overload:{name:'Annihilate',eff:'Max damage + roll debuff',dmg:23,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:2,rfmT:3},
  },
  guard:{
    recharge:{name:'Bulwark Link',eff:'+5 shield self, +5 shield ally',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:6,shT:2,shieldAlly:6},
    strike:{name:'Suppressing Fire',eff:'Damage + shield weakest ally',dmg:12,dot:0,dT:0,heal:0,rfe:0,shield:0,shieldAlly:6,shT:2},
    surge:{name:'Cover Field',eff:'Damage + shield weakest ally',dmg:11,dot:0,dT:0,heal:0,rfe:0,shield:0,shieldAlly:9,shT:2},
    crit:{name:'Barrier Burst',eff:'Damage + shield weakest ally',dmg:15,dot:0,dT:0,heal:0,rfe:0,shield:0,shieldAlly:7,shT:2},
    overload:{name:'Fortress Protocol',eff:'Heavy damage + big shield ally',dmg:18,dot:0,dT:0,heal:0,rfe:0,shield:0,shieldAlly:13,shT:2},
  },
  warden:{
    recharge:{name:'Field Service',eff:'+6 HP weakest ally, +6 shield self',dmg:0,dot:0,dT:0,heal:7,rfe:0,shield:7,shT:2},
    strike:{name:'Crushing Blow',eff:'10 dmg',dmg:11,dot:0,dT:0,heal:0,rfe:0,shield:0},
    surge:{name:'Sustained Fire',eff:'10 dmg, +3 DoT 3t',dmg:11,dot:3,dT:3,heal:0,rfe:0,shield:0},
    crit:{name:'Punisher',eff:'Very heavy damage',dmg:24,dot:0,dT:0,heal:0,rfe:0,shield:0},
    overload:{name:'Execution',eff:'Massive damage + team repair',dmg:29,dot:0,dT:0,heal:6,rfe:0,shield:0},
  },
  volt:{
    recharge:{name:'Grounding',eff:'—',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:0},
    strike:{name:'Arc Jab',eff:'Damage + DoT',dmg:9,dot:1,dT:2,heal:0,rfe:0,shield:0},
    surge:{name:'Chain Strike',eff:'Damage + DoT',dmg:11,dot:2,dT:2,heal:0,rfe:0,shield:0},
    crit:{name:'Conduction',eff:'Damage + DoT',dmg:13,dot:3,dT:2,heal:0,rfe:0,shield:0},
    overload:{name:'Meltdown Arc',eff:'Damage + DoT',dmg:15,dot:4,dT:3,heal:0,rfe:0,shield:0},
  },
  boss:{
    recharge:{name:'Shield Matrix',eff:'+22 shield to self',dmg:0,dot:0,dT:0,heal:0,rfe:0,shield:22,shT:2},
    strike:{name:'Suppressor',eff:'Damage + roll debuff',dmg:19,dmgP2:26,dot:0,dT:0,heal:0,rfe:0,shield:0,rfm:2,rfmT:2},
    surge:{name:'Core Blast',eff:'Heavy damage + DoT',dmg:23,dmgP2:29,dot:2,dT:2,heal:0,rfe:0,shield:0},
    crit:{name:'System Purge',eff:'Max damage + roll debuff',dmg:28,dmgP2:34,dot:0,dT:0,heal:0,rfe:3,shield:0,rfT:2},
    overload:{name:'Annihilate',eff:'Massive damage + wipe all hero shields',dmg:30,dmgP2:38,dot:0,dT:0,heal:0,rfe:0,shield:0,wipeShields:true},
  },
};

// ── ENEMY UNIT ROSTER (single source of truth: same display name -> same stats everywhere) ──
export const ENEMY_UNIT_DEFS: Record<string, Omit<EnemyDefinition, 'name'>> = {
  'Scrap Drone':{hp:40,dMin:5,dMax:9,type:'scrap',ai:'dumb'},
  'Rust Drone':{hp:35,dMin:5,dMax:8,type:'rust',ai:'dumb'},
  'Patrol Elite':{hp:65,dMin:12,dMax:16,type:'patrol',ai:'smart'},
  'Guard Elite':{hp:80,dMin:14,dMax:18,type:'guard',ai:'smart'},
  'Heavy Warden':{hp:115,dMin:17,dMax:23,type:'warden',ai:'smart'},
  'Volt Elite':{hp:90,dMin:15,dMax:21,type:'volt',ai:'smart'},
  'SCRAPMASTER':{hp:200,dMin:19,dMax:25,type:'boss',ai:'smart',p2dMin:27,p2dMax:35,pThr:95},
};

export function expandEnemyFromName(spawn: {name: string}): EnemyDefinition {
  const name = spawn && spawn.name;
  const def = ENEMY_UNIT_DEFS[name];
  if (!def) throw new Error('Unknown enemy unit name: ' + name);
  return { ...def, name };
}

// Per-battle multipliers on top of ENEMY_UNIT_DEFS (0 = Battle 1 ... 9 = Battle 10).
// Applies to enemy HP / phase threshold AND to ability damage/heal/shield/dot/rfm via getEnemyAbility (dmgScale).
// Tuning goal: gradual attrition (not ~100% clears through B7 then a B10-only cliff) and ~40-50% full-run WR.
// Early rows: gentle ramp so more runs fail mid-run; B10: slightly softer than a flat extrapolation of that ramp.
export const BATTLE_ENEMY_SCALE: {hp: number; dmg: number}[] = [
  { hp:1.05, dmg:1.04 },
  { hp:1.06, dmg:1.05 },
  { hp:1.06, dmg:1.05 },
  { hp:1.07, dmg:1.06 },
  { hp:1.07, dmg:1.06 },
  { hp:1.08, dmg:1.07 },
  { hp:1.07, dmg:1.06 },
  { hp:1.06, dmg:1.05 },
  { hp:1.05, dmg:1.05 },
  { hp:0.86, dmg:0.86 },
];

export function applyBattleEnemyScale(ex: any, battleIndex: number) {
  const sc = BATTLE_ENEMY_SCALE[Math.max(0, Math.min(9, battleIndex | 0))] || {hp: 1, dmg: 1};
  const hpM = sc.hp, dmgM = sc.dmg;
  const out = { ...ex };
  out.hp = Math.max(1, Math.round(ex.hp * hpM));
  out.dMin = Math.max(1, Math.round(ex.dMin * dmgM));
  out.dMax = Math.max(out.dMin, Math.round(ex.dMax * dmgM));
  if (ex.p2dMin != null) {
    out.p2dMin = Math.max(1, Math.round(ex.p2dMin * dmgM));
    out.p2dMax = Math.max(out.p2dMin, Math.round(ex.p2dMax * dmgM));
  }
  if (ex.pThr != null) out.pThr = Math.max(1, Math.round(ex.pThr * hpM));
  out.dmgScale = dmgM;
  return out;
}

// ── BATTLE TABLE (spawn lists: names only; stats come from ENEMY_UNIT_DEFS) ──
export const BATTLES: {enemies: {name: string}[]}[] = [
  {enemies:[{name:'Scrap Drone'}]},
  {enemies:[{name:'Scrap Drone'},{name:'Rust Drone'}]},
  {enemies:[{name:'Scrap Drone'},{name:'Rust Drone'}]},
  {enemies:[{name:'Patrol Elite'}]},
  {enemies:[{name:'Patrol Elite'},{name:'Scrap Drone'}]},
  {enemies:[{name:'Guard Elite'},{name:'Guard Elite'}]},
  {enemies:[{name:'Heavy Warden'}]},
  {enemies:[{name:'Rust Drone'},{name:'Heavy Warden'},{name:'Rust Drone'}]},
  {enemies:[{name:'Volt Elite'},{name:'Volt Elite'}]},
  {enemies:[{name:'Patrol Elite'},{name:'SCRAPMASTER'}]},
];
