import { HeroId, GamePhase, LogClass, LogMode, ProtocolAction } from './types';

export interface LogEntry {
  msg: string;
  cls: LogClass;
}

export interface TutorialState {
  active: boolean;
  step: number;
  playerRound: number;
  _ptCount: number;
  tutProtoPhase: number;
  pendingRoundBump: boolean;
  _glowSig: string | null;
}

export interface PendingEvolution {
  heroIdx: number;
  chosen: number | null;
}
