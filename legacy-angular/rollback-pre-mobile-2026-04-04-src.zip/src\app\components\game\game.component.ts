import { Component, ChangeDetectionStrategy, inject, OnInit, signal } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { CombatService } from '../../services/combat.service';
import { TargetingService } from '../../services/targeting.service';
import { ProtocolService } from '../../services/protocol.service';
import { HeaderComponent } from '../header/header.component';
import { EnemyZoneComponent } from '../enemy-zone/enemy-zone.component';
import { HeroZoneComponent } from '../hero-zone/hero-zone.component';
import { DiceTrayComponent } from '../dice-tray/dice-tray.component';
import { ProtocolStripComponent } from '../protocol-strip/protocol-strip.component';
import { BattleLogComponent } from '../battle-log/battle-log.component';
import { ResultOverlayComponent } from '../overlays/result-overlay.component';
import { HelpOverlayComponent } from '../overlays/help-overlay.component';
import { EvolutionOverlayComponent } from '../overlays/evolution-overlay.component';

@Component({
  selector: 'app-game',
  standalone: true,
  imports: [
    HeaderComponent,
    EnemyZoneComponent,
    HeroZoneComponent,
    DiceTrayComponent,
    ProtocolStripComponent,
    BattleLogComponent,
    ResultOverlayComponent,
    HelpOverlayComponent,
    EvolutionOverlayComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div id="app">
      <app-header (helpClicked)="helpOpen.set(true)" />
      <div class="lanes">
        <app-enemy-zone />
        <app-dice-tray />
        <app-hero-zone />
        <app-protocol-strip />
        <app-battle-log />
      </div>
    </div>
    <app-result-overlay />
    <app-help-overlay [isOpen]="helpOpen()" (closed)="helpOpen.set(false)" />
    <app-evolution-overlay />
  `,
  styles: [`
    #app { position: relative; z-index: 1; max-width: 760px; min-width: 760px; margin: 0 auto; padding: 12px; }
  `],
})
export class GameComponent implements OnInit {
  private state = inject(GameStateService);
  private combat = inject(CombatService);

  helpOpen = signal(false);

  ngOnInit(): void {
    // Initialize game
    this.state.initHeroes();
    this.combat.initBattle();
  }
}
