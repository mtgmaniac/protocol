import { Zone } from './types';

export interface HeroAbility {
  zone: Zone;
  range: [number, number];
  name: string;
  eff: string;
  dmg: number;
  dMin: number;
  dMax: number;
  dot: number;
  dT: number;
  rfe: number;
  rfT?: number;
  heal: number;
  shTgt?: boolean;
  shield?: number;
  shT?: number;
  shieldAll?: boolean;
  healTgt?: boolean;
  healAll?: boolean;
  healLowest?: boolean;
  revive?: boolean;
  rfm?: number;
  rfmT?: number;
  /** If set, player picks an ally; that hero receives the rfm roll buff instead of the caster. */
  rfmTgt?: boolean;
  cloak?: boolean;
  taunt?: boolean;
  blastAll?: boolean;
  multiHit?: boolean;
  ignSh?: boolean;
  splitDmg?: boolean;
  rfeAll?: boolean;
  rfeOnly?: boolean;
}

export interface EnemyAbility {
  name: string;
  eff: string;
  dmg: number;
  dmgP2?: number;
  dot: number;
  dT: number;
  heal: number;
  rfe: number;
  rfT?: number;
  shield: number;
  shT?: number;
  shieldAlly?: number;
  rfm?: number;
  rfmT?: number;
  wipeShields?: boolean;
  zone?: Zone;
}

export type EnemyAbilitySuite = Record<Zone, EnemyAbility>;
