import { Component, ChangeDetectionStrategy, input, computed, inject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-portrait-frame',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="portrait-frame"
         [class.pf-cloaked]="isCloaked()"
         [innerHTML]="safeSvg()">
    </div>
  `,
  styles: [`
    .portrait-frame {
      width: 93px; height: 111px; border-radius: 6px;
      border: 1px solid rgba(255,255,255,.10);
      background:
        linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.01)),
        repeating-linear-gradient(0deg, rgba(255,255,255,.04), rgba(255,255,255,.04) 1px, transparent 1px, transparent 6px),
        radial-gradient(120px 120px at 50% 30%, rgba(46,125,212,.10), transparent 55%),
        rgba(6,14,24,.55);
      box-shadow: inset 0 0 0 1px rgba(0,0,0,.35);
      display: flex; align-items: flex-end; justify-content: center; overflow: hidden;
      position: relative;
    }
    .portrait-frame ::ng-deep svg { width: 93px; height: 111px; display: block; }
    .portrait-frame::after {
      content: ''; position: absolute; inset: 0; pointer-events: none; opacity: 0;
      background: radial-gradient(90px 90px at 50% 45%, var(--pf, rgba(255,255,255,.0)), rgba(255,255,255,0) 65%);
    }
    .portrait-frame.pf-cloaked::before {
      content: ''; position: absolute; inset: 0; pointer-events: none; opacity: .25;
      background: linear-gradient(180deg, rgba(160,90,255,.55), rgba(120,70,220,.25));
      mix-blend-mode: screen;
    }
  `],
})
export class PortraitFrameComponent {
  svg = input.required<string>();
  isCloaked = input(false);

  private sanitizer = inject(DomSanitizer);

  safeSvg = computed(() =>
    this.sanitizer.bypassSecurityTrustHtml(this.svg())
  );
}
