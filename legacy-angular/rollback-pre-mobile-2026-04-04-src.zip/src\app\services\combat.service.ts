import { Injectable } from '@angular/core';
import { EnemyAbility } from '../models/ability.interface';
import { EnemyState, createEnemyState } from '../models/enemy.interface';
import { HeroState } from '../models/hero.interface';
import { Zone } from '../models/types';
import { ENEMY_ABILITIES } from '../data/enemies.data';
import { expandEnemyFromName, applyBattleEnemyScale, BATTLES } from '../data/enemies.data';
import { GameStateService } from './game-state.service';
import { DiceService } from './dice.service';
import { TargetingService } from './targeting.service';
import { AnimationService, STEP_MS, SUBFLASH_MS } from './animation.service';
import { LogService } from './log.service';
import { ProtocolService } from './protocol.service';
import { EvolutionService } from './evolution.service';

@Injectable({ providedIn: 'root' })
export class CombatService {
  constructor(
    private state: GameStateService,
    private dice: DiceService,
    private targeting: TargetingService,
    private anim: AnimationService,
    private log: LogService,
    private protocol: ProtocolService,
    private evolution: EvolutionService,
  ) {}

  // ── Enemy ability resolution ──

  getEnemyAbility(e: EnemyState, zone: Zone): EnemyAbility {
    const suite = ENEMY_ABILITIES[e.type] || ENEMY_ABILITIES['scrap'];
    const base = suite[zone];
    if (!base) return { name: '?', eff: '—', dmg: 0, dot: 0, dT: 0, heal: 0, rfe: 0, shield: 0 };
    const ab: EnemyAbility = { ...base };
    const scale = e.dmgScale || 1;
    if (ab.dmg > 0) ab.dmg = Math.round(ab.dmg * scale);
    if (ab.dmgP2 && ab.dmgP2 > 0) ab.dmgP2 = Math.round(ab.dmgP2 * scale);
    if (ab.dot > 0) ab.dot = Math.round(ab.dot * scale);
    if (ab.heal > 0) ab.heal = Math.round(ab.heal * scale);
    if (ab.shield > 0) ab.shield = Math.round(ab.shield * scale);
    if (ab.rfm && ab.rfm > 0) ab.rfm = Math.round(ab.rfm * scale);
    if ((ab.shieldAlly || 0) > 0) ab.shieldAlly = Math.round((ab.shieldAlly || 0) * scale);
    // Phase 2 boss damage override
    if (e.p2 && ab.dmgP2) ab.dmg = ab.dmgP2;
    return ab;
  }

  /** Commit a raw d20 for one enemy (after debuff); updates zone + plan. */
  applyEnemyAbilityRoll(idx: number, preRoll: number): void {
    const e = this.state.enemies()[idx];
    if (!e || e.dead) return;
    const effR = Math.max(1, preRoll - (e.rfe || 0));
    const zone = this.dice.getEnemyZone(effR);
    const plan = this.getEnemyAbility(e, zone);
    plan.zone = zone;
    this.state.updateEnemy(idx, {
      preRoll,
      effRoll: effR,
      curZone: zone,
      plan,
    });
  }

  rollEnemyAbility(idx: number): void {
    this.applyEnemyAbilityRoll(idx, this.dice.d20());
  }

  /** Clear queued enemy abilities until the squad roll reveals them. */
  clearEnemyPlansForNextPlayerRound(): void {
    this.state.enemies().forEach((e, i) => {
      if (e.dead) return;
      this.state.updateEnemy(i, {
        preRoll: 0,
        effRoll: 0,
        curZone: 'recharge',
        plan: null,
      });
    });
  }

  /** Roll fresh enemy plans when all squad dice are set (individual clicks, no tray anim). */
  rollFreshEnemyPlansForReveal(): void {
    const enemies = this.state.enemies();
    for (let i = 0; i < enemies.length; i++) {
      if (!enemies[i].dead) this.applyEnemyAbilityRoll(i, this.dice.d20());
    }
    this.targeting.assignTargets();
  }

  /** Apply precomputed d20s from the tray animation, then refresh targeting. */
  applyEnemyAbilityRollsFromPreRolls(pairs: { enemyIndex: number; preRoll: number }[]): void {
    for (const { enemyIndex, preRoll } of pairs) {
      this.applyEnemyAbilityRoll(enemyIndex, preRoll);
    }
    this.targeting.assignTargets();
  }

  recomputeEnemy(idx: number): void {
    const e = this.state.enemies()[idx];
    const effR = Math.max(1, e.preRoll - (e.rfe || 0));
    const zone = this.dice.getEnemyZone(effR);
    const plan = this.getEnemyAbility(e, zone);
    plan.zone = zone;
    this.state.updateEnemy(idx, { effRoll: effR, curZone: zone, plan });
    this.targeting.assignTargets();
  }

  applyDamageToEnemy(idx: number, dmg: number, src: string, ignSh: boolean): void {
    const e = this.state.enemies()[idx];
    let actualDmg = dmg;
    if (e.shield > 0 && e.shT > 0 && !ignSh) {
      const absorbed = Math.min(e.shield, actualDmg);
      actualDmg = Math.max(0, actualDmg - absorbed);
      const newShield = e.shield - absorbed;
      this.state.updateEnemy(idx, {
        shield: newShield,
        shT: newShield <= 0 ? 0 : e.shT,
      });
      if (absorbed > 0) this.log.log(`▸ ${e.name}'s shield absorbs ${absorbed}.`, 'sy');
    }
    if (actualDmg <= 0) return;
    const newHp = Math.max(0, e.currentHp - actualDmg);
    this.state.updateEnemy(idx, { currentHp: newHp });
    this.log.log(`▸ ${src} → ${e.name}: ${actualDmg} dmg. (${newHp}/${e.maxHp} HP)`, 'pl');
    this.checkDead(idx);
  }

  checkDead(idx: number): void {
    const e = this.state.enemies()[idx];
    if (e.currentHp <= 0 && !e.dead) {
      this.state.updateEnemy(idx, { dead: true });
      this.log.log(`▸ ${e.name} destroyed.`, 'sy');
      const enemies = this.state.enemies();
      const nextAlive = enemies.findIndex(en => !en.dead);
      if (nextAlive >= 0) {
        this.state.target.set(nextAlive);
      }
    }
    // Boss phase 2
    const updated = this.state.enemies()[idx];
    if (updated.type === 'boss' && !updated.p2 && updated.pThr && updated.currentHp <= updated.pThr) {
      this.state.updateEnemy(idx, { p2: true });
      this.log.log(`▸ ⚠ SCRAPMASTER PHASE 2.`, 'sy');
    }
  }

  // ── Battle initialization ──

  initBattle(): void {
    const battleIdx = this.state.battle();
    const battleDef = BATTLES[battleIdx];
    if (!battleDef) return;

    const enemies: EnemyState[] = battleDef.enemies.map((spawn, i) => {
      const raw = expandEnemyFromName(spawn);
      const scaled = applyBattleEnemyScale(raw, battleIdx);
      return createEnemyState(scaled, i);
    });

    this.state.enemies.set(enemies);
    this.state.phase.set('player');
    this.state.target.set(0);
    this.state.rfmPen.set(0);
    this.state.rfmT.set(0);
    this.state.tauntHeroId.set(null);
    this.state.selectedHeroIdx.set(null);
    this.state.pendingProtocol.set(null);
    this.state.rollAllInProgress.set(false);
    this.state.rollAnimInProgress.set(false);
    this.state.squadDiceSettling.set(false);
    this.state.enemyDiceSettling.set(false);
    this.state.enemyTrayRevealed.set(false);
    this.state.showOverlay.set(false);

    // Fresh battle: no squad dice or locks until ROLL ALL / individual rolls (carries over from prior battle otherwise)
    this.state.heroes().forEach((_, i) => this.state.resetHeroForNewRound(i));

    // Enemy abilities roll when the player reveals the tray (ROLL ALL / last squad die)
    this.targeting.assignTargets();

    // Grant protocol
    this.state.protocol.set(0);
    this.protocol.grantForNewRound();

    this.log.log(`— BATTLE ${battleIdx + 1} START —`, 'sy');
  }

  // ── Roll helpers ──

  /** Called by DiceTray after animation applies the roll value to state */
  clearAndAutoTarget(heroIdx: number): void {
    this.targeting.clearHeroTargetingOnRollChange(heroIdx);
    this.targeting.runAutoTargetForHero(heroIdx);
  }

  /** Roll a single hero die (no animation — instant, for clicking individual dice) */
  rollHero(idx: number): void {
    const h = this.state.heroes()[idx];
    if (!h || h.currentHp <= 0 || h.roll !== null) return;
    if (this.state.phase() !== 'player') return;

    let raw = this.dice.d20();
    const rfmPen = this.state.rfmPen();
    if (rfmPen > 0) raw = Math.max(1, raw - rfmPen);
    const buffed = h.rollBuff > 0 ? Math.min(20, raw + h.rollBuff) : raw;
    this.state.updateHero(idx, { roll: buffed, rawRoll: raw });
    this.targeting.clearHeroTargetingOnRollChange(idx);
    this.targeting.runAutoTargetForHero(idx);
    if (this.state.heroes().every(x => x.currentHp <= 0 || x.roll !== null)) {
      this.rollFreshEnemyPlansForReveal();
      this.state.enemyTrayRevealed.set(true);
    }
  }

  // ── End turn (player turn resolution) ──

  async endTurn(): Promise<void> {
    if (this.state.phase() !== 'player') return;

    // Auto-target any remaining heroes
    const heroes = this.state.heroes();
    heroes.forEach((_, i) => this.targeting.runAutoTargetForHero(i));
    if (!this.targeting.allHeroesReadyForEndTurn()) return;

    // Tick roll buff durations
    heroes.forEach((h, i) => {
      if (h.rollBuffT > 0) {
        const newT = h.rollBuffT - 1;
        this.state.updateHero(i, {
          rollBuffT: newT,
          rollBuff: newT <= 0 ? 0 : h.rollBuff,
        });
      }
    });

    // Force-roll any unrolled alive heroes
    this.state.heroes().forEach((h, i) => {
      if (h.currentHp <= 0 || h.roll !== null) return;
      let raw = this.dice.d20();
      if (this.state.rfmPen() > 0) raw = Math.max(1, raw - this.state.rfmPen());
      const buffed = h.rollBuff > 0 ? Math.min(20, raw + h.rollBuff) : raw;
      this.state.updateHero(i, { roll: buffed, rawRoll: raw, noRR: true });
      this.targeting.clearHeroTargetingOnRollChange(i);
      this.targeting.runAutoTargetForHero(i);
    });

    // Tick enemy DoTs
    this.state.enemies().forEach((e, i) => {
      if (e.dead) return;
      if (e.dot > 0 && e.dT > 0) {
        this.applyDamageToEnemy(i, e.dot, 'DoT', false);
        const newDT = e.dT - 1;
        this.state.updateEnemy(i, { dT: newDT, dot: newDT <= 0 ? 0 : e.dot });
      }
      if (e.rfT > 0) {
        const newRT = e.rfT - 1;
        this.state.updateEnemy(i, { rfT: newRT, rfe: newRT <= 0 ? 0 : e.rfe });
      }
    });

    // Tick global roll modifier
    if (this.state.rfmT() > 0) {
      const newT = this.state.rfmT() - 1;
      this.state.rfmT.set(newT);
      if (newT <= 0) this.state.rfmPen.set(0);
    }

    // Check if all enemies dead from DoT
    if (this.state.enemies().every(e => e.dead)) { this.won(); return; }

    // Resolve each hero's ability
    for (let hi = 0; hi < this.state.heroes().length; hi++) {
      const h = this.state.heroes()[hi];
      if (h.currentHp <= 0) continue;
      const er = this.dice.effRoll(h);
      if (er === null) continue;
      const ab = this.dice.getAbility(h, er);
      if (!ab) continue;

      const enemies = this.state.enemies();
      const tgtIdx = h.lockedTarget !== undefined && h.lockedTarget !== null ? h.lockedTarget : 0;
      const tgtE = enemies[tgtIdx];

      // ── Revive ──
      if (ab.revive) {
        const dead = this.state.heroes().map((x, idx) => ({ x, idx })).filter(z => z.x.currentHp <= 0);
        const ti = h.reviveTgtIdx != null ? h.reviveTgtIdx : (dead[0]?.idx ?? null);
        if (ti != null) {
          const tgt = this.state.heroes()[ti];
          if (tgt && tgt.currentHp <= 0) {
            const revHp = Math.max(1, Math.round(tgt.maxHp * 0.5));
            this.state.updateHero(ti, { currentHp: revHp, dot: 0, dT: 0, shield: 0, shT: 0 });
            this.log.log(`▸ ${h.name} → ${ab.name}. Revived ${tgt.name} at ${revHp}/${tgt.maxHp} HP.`, 'pl');
          }
        }
      }
      // ── Shield all (independent — can combine with damage, etc.) ──
      if (ab.shieldAll && (ab.shield || 0) > 0) {
        this.state.heroes().forEach((x, idx) => {
          if (x.currentHp > 0) {
            this.state.updateHero(idx, { shield: (x.shield || 0) + (ab.shield || 0), shT: ab.shT || 2 });
          }
        });
        this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.shield} shield (all allies).`, 'pl');
      }
      // ── Heal all ──
      if (ab.healAll && (ab.heal || 0) > 0) {
        this.state.heroes().forEach((x, idx) => {
          if (x.currentHp > 0 && x.currentHp < x.maxHp) {
            this.state.updateHero(idx, { currentHp: Math.min(x.maxHp, x.currentHp + ab.heal) });
          }
        });
        this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.heal} HP (all allies).`, 'pl');
      }
      // ── Shield targeted ally (explicit pick only — no default target) ──
      if (ab.shTgt && (ab.shield || 0) > 0 && h.shTgtIdx != null) {
        const si = h.shTgtIdx;
        const sH = this.state.heroes()[si];
        if (sH && sH.currentHp > 0) {
          this.state.updateHero(si, { shield: (sH.shield || 0) + (ab.shield || 0), shT: ab.shT || 2 });
          this.log.log(`▸ ${h.name} → ${ab.name} on ${sH.name} (+${ab.shield} shield).`, 'pl');
        }
      }
      // ── Self shield (no ally pick / not team-wide) ──
      if ((ab.shield || 0) > 0 && !ab.shieldAll && !ab.shTgt) {
        this.state.updateHero(hi, { shield: (h.shield || 0) + (ab.shield || 0), shT: ab.shT || 2 });
        this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.shield} shield (self).`, 'pl');
      }
      // ── Heal lowest ──
      if (ab.healLowest && (ab.heal || 0) > 0) {
        const alive = this.state.heroes().map((x, idx) => ({ x, idx })).filter(z => z.x.currentHp > 0);
        const best = alive.reduce((a, b) => (a.x.currentHp / a.x.maxHp) <= (b.x.currentHp / b.x.maxHp) ? a : b, alive[0]);
        if (best && best.x.currentHp < best.x.maxHp) {
          this.state.updateHero(best.idx, { currentHp: Math.min(best.x.maxHp, best.x.currentHp + ab.heal) });
          this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.heal} HP on ${best.x.name}.`, 'pl');
        }
      }
      // ── Heal targeted ally (explicit pick only — no default target) ──
      if (ab.healTgt && (ab.heal || 0) > 0 && h.healTgtIdx != null) {
        const ti = h.healTgtIdx;
        const heroes = this.state.heroes();
        if (ti >= 0 && ti < heroes.length) {
          const tgt = heroes[ti];
          if (tgt && tgt.currentHp > 0 && tgt.currentHp < tgt.maxHp) {
            this.state.updateHero(ti, { currentHp: Math.min(tgt.maxHp, tgt.currentHp + ab.heal) });
            this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.heal} HP on ${tgt.name}.`, 'pl');
          }
        }
      }
      // ── Self heal + damage (Neural Override–style: not ally heal / lowest / shield pick) ──
      if (
        (ab.heal || 0) > 0 &&
        !ab.healTgt &&
        !ab.healLowest &&
        !ab.healAll &&
        !ab.shTgt &&
        (ab.dmg || 0) > 0
      ) {
        if (h.currentHp < h.maxHp) {
          this.state.updateHero(hi, { currentHp: Math.min(h.maxHp, h.currentHp + ab.heal) });
          this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.heal} HP (self).`, 'pl');
        }
      }
      // ── Self heal only (no damage component) ──
      if (
        (ab.heal || 0) > 0 &&
        !ab.healTgt &&
        !ab.healLowest &&
        !ab.healAll &&
        !ab.shTgt &&
        !(ab.dmg || 0)
      ) {
        if (h.currentHp < h.maxHp) {
          this.state.updateHero(hi, { currentHp: Math.min(h.maxHp, h.currentHp + ab.heal) });
          this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.heal} HP.`, 'pl');
        }
      }
      // ── Damage (orthogonal to ally-targeted heals/shields above) ──
      if ((ab.blastAll || ab.multiHit) && (ab.dmg || 0) > 0) {
        this.state.enemies().forEach((e, idx) => {
          if (e.dead) return;
          this.applyDamageToEnemy(idx, ab.dmg, h.name, !!(ab.ignSh));
        });
      } else if (ab.splitDmg) {
        const alloc = h.splitAlloc || {};
        const entries = Object.entries(alloc)
          .filter(([, v]) => v > 0)
          .map(([k, v]) => ({ ei: parseInt(k), dmg: v }))
          .filter(x => this.state.enemies()[x.ei] && !this.state.enemies()[x.ei].dead);
        if (entries.length) {
          entries.forEach(x => {
            if (x.dmg > 0) {
              this.applyDamageToEnemy(x.ei, x.dmg, h.name, !!(ab.ignSh));
              this.log.log(`▸ ${h.name} splits ${x.dmg} dmg → ${this.state.enemies()[x.ei].name}.`, 'pl');
            }
          });
        } else if (tgtE && !tgtE.dead && (ab.dmg || 0) > 0) {
          this.applyDamageToEnemy(tgtIdx, ab.dmg, h.name, !!(ab.ignSh));
        }
      } else if ((ab.dmg || 0) > 0 && tgtE && !tgtE.dead) {
        this.applyDamageToEnemy(tgtIdx, ab.dmg, h.name, !!(ab.ignSh));
      }

      // ── Secondary effects: squad roll buff (self or chosen ally) ──
      if (ab.rfm && ab.rfm > 0) {
        if (ab.rfmTgt) {
          const ti = h.rfmTgtIdx;
          const heroes = this.state.heroes();
          if (ti != null && ti >= 0 && ti < heroes.length) {
            const tgt = heroes[ti];
            if (tgt && tgt.currentHp > 0) {
              this.state.updateHero(ti, {
                rollBuff: (tgt.rollBuff || 0) + ab.rfm,
                rollBuffT: Math.max(tgt.rollBuffT || 0, ab.rfmT || 1),
              });
              this.log.log(
                `▸ ${h.name} → ${ab.name}. +${ab.rfm} roll buff on ${tgt.name} (${ab.rfmT || 1}t).`,
                'pl',
              );
            }
          }
        } else {
          this.state.updateHero(hi, {
            rollBuff: (h.rollBuff || 0) + ab.rfm,
            rollBuffT: Math.max(h.rollBuffT || 0, ab.rfmT || 1),
          });
          this.log.log(`▸ ${h.name} → ${ab.name}. +${ab.rfm} roll buff next ${ab.rfmT || 1}t.`, 'pl');
        }
      }
      if (ab.cloak) {
        this.state.updateHero(hi, { cloaked: true });
        this.log.log(`▸ ${h.name} is cloaked (80% dodge next hit).`, 'pl');
      }
      if (ab.taunt) {
        this.state.tauntHeroId.set(h.id);
        this.targeting.assignTargets();
        this.log.log(`▸ ${h.name} taunts — enemies will target ${h.name} this turn.`, 'pl');
      }
      if (ab.dot > 0) {
        if (ab.blastAll) {
          this.state.enemies().forEach((e, idx) => {
            if (e.dead) return;
            this.state.updateEnemy(idx, {
              dot: (e.dot || 0) + ab.dot,
              dT: Math.max(e.dT || 0, ab.dT || 0),
            });
          });
          this.log.log(`▸ Enemies poisoned (${ab.dot} DoT, ${ab.dT}t).`, 'pl');
        } else if (tgtE && !tgtE.dead) {
          this.state.updateEnemy(tgtIdx, {
            dot: (tgtE.dot || 0) + ab.dot,
            dT: Math.max(tgtE.dT || 0, ab.dT || 0),
          });
          this.log.log(`▸ ${tgtE.name} poisoned (${ab.dot} DoT, ${ab.dT}t).`, 'pl');
        }
      }
      if (ab.rfe > 0) {
        if (ab.rfeAll) {
          this.state.enemies().forEach((e, idx) => {
            if (e.dead) return;
            this.state.updateEnemy(idx, { rfe: (e.rfe || 0) + ab.rfe, rfT: ab.rfT || 1 });
            this.recomputeEnemy(idx);
          });
        } else if (tgtE && !tgtE.dead) {
          this.state.updateEnemy(tgtIdx, { rfe: (tgtE.rfe || 0) + ab.rfe, rfT: ab.rfT || 1 });
          this.recomputeEnemy(tgtIdx);
        }
      }
    }

    // Check win
    if (this.state.enemies().every(e => e.dead)) { this.won(); return; }

    // Switch to enemy phase
    this.state.phase.set('enemy');
    setTimeout(() => this.enemyTurn(), 700);
  }

  // ── Enemy turn ──

  async enemyTurn(): Promise<void> {
    this.log.log(`— ENEMY TURN —`, 'sy');
    this.state.tauntHeroId.set(null);

    // Tick hero DoTs
    this.state.heroes().forEach((h, i) => {
      if (h.dot > 0 && h.dT > 0) {
        const newHp = Math.max(0, h.currentHp - h.dot);
        const newDT = h.dT - 1;
        this.state.updateHero(i, {
          currentHp: newHp,
          dT: newDT,
          dot: newDT <= 0 ? 0 : h.dot,
        });
        this.log.log(`▸ ${h.name} takes ${h.dot} DoT damage.`, 'en');
      }
    });

    if (this.state.heroes().every(h => h.currentHp <= 0)) { this.lost(); return; }

    // Enemy actions
    for (let ei = 0; ei < this.state.enemies().length; ei++) {
      const e = this.state.enemies()[ei];
      if (e.dead) continue;
      const act = e.plan;
      if (!act) continue;

      // Damage
      if (act.dmg > 0) {
        const heroes = this.state.heroes();
        const hIdx = heroes.findIndex(h => h.id === e.targeting && h.currentHp > 0);
        if (hIdx >= 0) {
          const ht = heroes[hIdx];
          let dmg = act.dmg;
          if (ht.cloaked && Math.random() < 0.8) {
            this.state.updateHero(hIdx, { cloaked: false });
            this.log.log(`▸ ${e.name} attacks ${ht.name} — MISS! (Cloak)`, 'bl');
          } else {
            this.state.updateHero(hIdx, { cloaked: false });
            // Shield absorption
            if (ht.shield > 0 && ht.shT > 0) {
              const absorbed = Math.min(ht.shield, dmg);
              dmg = Math.max(0, dmg - absorbed);
              const newSh = ht.shield - absorbed;
              this.state.updateHero(hIdx, { shield: newSh, shT: newSh <= 0 ? 0 : ht.shT });
              if (absorbed > 0) this.log.log(`▸ ${ht.name}'s shield absorbs ${absorbed}.`, 'sy');
            }
            const newHp = Math.max(0, this.state.heroes()[hIdx].currentHp - dmg);
            this.state.updateHero(hIdx, { currentHp: newHp });
            this.log.log(`▸ ${e.name} → ${ht.name}: ${dmg} dmg. (${newHp}/${ht.maxHp} HP)`, 'en');
            if (newHp <= 0) this.log.log(`▸ ${ht.name} is down.`, 'sy');
          }
        }
      }

      // Enemy self-shield
      if (act.shield > 0) {
        this.state.updateEnemy(ei, { shield: (e.shield || 0) + act.shield, shT: act.shT || 2 });
        this.log.log(`▸ ${e.name} → ${act.name}! (+${act.shield} shield)`, 'en');
      }

      // Shield ally
      if ((act.shieldAlly || 0) > 0) {
        const others = this.state.enemies().filter(x => !x.dead && x.id !== e.id);
        if (others.length) {
          const tgt = others.reduce((a, b) => a.currentHp < b.currentHp ? a : b, others[0]);
          const tgtIdx = this.state.enemies().findIndex(x => x.id === tgt.id);
          this.state.updateEnemy(tgtIdx, {
            shield: (tgt.shield || 0) + (act.shieldAlly || 0),
            shT: Math.max(tgt.shT || 0, act.shT || 2),
          });
          this.log.log(`▸ ${e.name} → ${tgt.name}: +${act.shieldAlly} shield (ally).`, 'en');
        }
      }

      // Heal weakest ally
      if (act.heal > 0) {
        const alive = this.state.enemies().filter(x => !x.dead);
        const weakest = alive.reduce((a, b) => a.currentHp < b.currentHp ? a : b, alive[0]);
        if (weakest) {
          const wIdx = this.state.enemies().findIndex(x => x.id === weakest.id);
          const newHp = Math.min(weakest.maxHp, weakest.currentHp + act.heal);
          this.state.updateEnemy(wIdx, { currentHp: newHp });
          this.log.log(`▸ ${e.name} repairs ${weakest.name} +${act.heal} HP!`, 'en');
        }
      }

      // Global roll debuff
      if (act.rfm && act.rfm > 0) {
        this.state.rfmPen.update(v => v + act.rfm!);
        this.state.rfmT.set(act.rfmT || 2);
        this.log.log(`▸ ${e.name} → ${act.name}! -${act.rfm} roll debuff for ${act.rfmT}t.`, 'en');
      }

      // Wipe shields
      if (act.wipeShields) {
        this.state.heroes().forEach((h, i) => {
          this.state.updateHero(i, { shield: 0, shT: 0 });
        });
        this.log.log(`▸ SCRAPMASTER ANNIHILATES — all shields wiped!`, 'en');
      }

      // Apply DoT to target hero
      if (act.dot > 0) {
        const hIdx = this.state.heroes().findIndex(h => h.id === e.targeting && h.currentHp > 0);
        if (hIdx >= 0) {
          const ht = this.state.heroes()[hIdx];
          this.state.updateHero(hIdx, {
            dot: (ht.dot || 0) + act.dot,
            dT: Math.max(ht.dT || 0, act.dT || 2),
          });
        }
      }
    }

    // Decay shields
    this.state.enemies().forEach((e, i) => {
      if (e.dead) return;
      if (e.shT > 0) {
        const newT = e.shT - 1;
        this.state.updateEnemy(i, { shT: newT, shield: newT <= 0 ? 0 : e.shield });
      }
    });
    this.state.heroes().forEach((h, i) => {
      if (h.shT > 0) {
        const newT = h.shT - 1;
        this.state.updateHero(i, { shT: newT, shield: newT <= 0 ? 0 : h.shield });
      }
    });

    // Check loss
    if (this.state.heroes().every(h => h.currentHp <= 0)) { this.lost(); return; }

    // Next player round: no squad rolls and no enemy plan until reveal
    this.clearEnemyPlansForNextPlayerRound();
    this.state.heroes().forEach((_, i) => this.state.resetHeroForNewRound(i));
    this.targeting.assignTargets();

    this.state.phase.set('player');
    this.state.selectedHeroIdx.set(null);
    this.state.pendingProtocol.set(null);
    this.state.rollAllInProgress.set(false);
    this.state.squadDiceSettling.set(false);
    this.state.squadSettleHeroIdx.set(null);
    this.state.enemyTrayRevealed.set(false);

    this.protocol.grantForNewRound();
    this.log.log(`— PLAYER TURN —`, 'sy');
  }

  // ── Win / Loss ──

  won(): void {
    this.state.phase.set('over');
    this.log.log(`▸ All enemies down. Battle ${this.state.battle() + 1} complete.`, 'vi');

    if (this.state.battle() >= 9) {
      this.showOverlay('VICTORY', 'Scrapmaster destroyed. Scrapfields clear.', 'NEW RUN ↺', true, () => this.newRun());
      return;
    }

    // Award HRS
    this.evolution.awardHrs();

    // Check evolution eligibility
    const eligible = this.evolution.getEligibleHeroes();
    if (eligible.length > 0) {
      this.state.pendingEvolutions.set(eligible.map(i => ({ heroIdx: i, chosen: null })));
      // Evolution overlay will show automatically via signal
    } else {
      this.showOverlay('BATTLE CLEARED', `Battle ${this.state.battle() + 1} complete.`, 'NEXT BATTLE ▶', true, () => this.nextBattle());
    }
  }

  lost(): void {
    this.state.phase.set('over');
    this.log.log(`▸ Squad wiped. Run terminated.`, 'de');
    this.showOverlay('SQUAD WIPED', `Eliminated at battle ${this.state.battle() + 1}.`, 'NEW RUN ↺', false, () => this.newRun());
  }

  nextBattle(): void {
    this.state.showOverlay.set(false);
    this.state.battle.update(b => b + 1);

    // Restore hero HP: alive = 100%, dead = revive at 80%
    this.state.heroes().forEach((h, i) => {
      if (h.currentHp > 0) {
        this.state.updateHero(i, { currentHp: h.maxHp, shield: 0, shT: 0, dot: 0, dT: 0, cloaked: false });
      } else {
        this.state.updateHero(i, {
          currentHp: Math.max(1, Math.round(h.maxHp * 0.8)),
          shield: 0, shT: 0, dot: 0, dT: 0, cloaked: false,
        });
      }
    });

    this.initBattle();
  }

  newRun(): void {
    this.state.reset();
    this.state.initHeroes();
    this.state.battle.set(0);
    this.initBattle();
  }

  private showOverlay(title: string, sub: string, btnText: string, isVictory: boolean, action: () => void): void {
    this.state.overlayTitle.set(title);
    this.state.overlaySub.set(sub);
    this.state.overlayBtnText.set(btnText);
    this.state.overlayIsVictory.set(isVictory);
    this.state.overlayBtnAction.set(action);
    this.state.showOverlay.set(true);
  }
}
