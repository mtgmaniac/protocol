import { Injectable, computed, signal } from '@angular/core';
import { HeroState, createHeroState } from '../models/hero.interface';
import { EnemyState } from '../models/enemy.interface';
import { LogEntry, PendingEvolution, TutorialState } from '../models/game-state.interface';
import { GamePhase, HeroId, LogClass, LogMode, ProtocolAction } from '../models/types';
import { ALL_HEROES } from '../data/heroes.data';

@Injectable({ providedIn: 'root' })
export class GameStateService {
  // ── Primary state signals ──
  readonly battle = signal(0);
  readonly phase = signal<GamePhase>('player');
  readonly heroes = signal<HeroState[]>([]);
  readonly enemies = signal<EnemyState[]>([]);
  readonly target = signal(0);
  readonly log = signal<LogEntry[]>([]);
  readonly rfmPen = signal(0);
  readonly rfmT = signal(0);
  readonly tauntHeroId = signal<HeroId | null>(null);
  readonly pendingEvolutions = signal<PendingEvolution[]>([]);
  readonly logMode = signal<LogMode>('min');
  readonly logOpen = signal(false);
  readonly animOn = signal(true);
  readonly tutorial = signal<TutorialState | null>(null);
  readonly protocol = signal(0);
  readonly selectedHeroIdx = signal<number | null>(null);
  readonly pendingProtocol = signal<ProtocolAction>(null);
  readonly rollAllInProgress = signal(false);
  readonly rollAnimInProgress = signal(false);
  readonly squadDiceSettling = signal(false);
  readonly squadSettleHeroIdx = signal<number | null>(null);
  readonly enemyDiceSettling = signal(false);
  readonly enemyTrayRevealed = signal(false);

  // ── Overlay signals ──
  readonly showOverlay = signal(false);
  readonly overlayTitle = signal('');
  readonly overlaySub = signal('');
  readonly overlayBtnText = signal('');
  readonly overlayBtnAction = signal<(() => void) | null>(null);
  readonly overlayIsVictory = signal(false);

  // ── Computed signals ──
  readonly allHeroesRolled = computed(() =>
    this.heroes().every(h => h.currentHp <= 0 || h.roll !== null)
  );

  readonly allHeroesReady = computed(() =>
    this.heroes().every(h => h.currentHp <= 0 || (h.roll !== null && h.confirmed))
  );

  readonly livingHeroes = computed(() =>
    this.heroes().filter(h => h.currentHp > 0)
  );

  readonly livingEnemies = computed(() =>
    this.enemies().filter(e => !e.dead)
  );

  readonly isPlayerPhase = computed(() =>
    this.phase() === 'player'
  );

  // ── Mutation methods ──
  updateHero(index: number, patch: Partial<HeroState>): void {
    this.heroes.update(heroes =>
      heroes.map((h, i) => i === index ? { ...h, ...patch } : h)
    );
  }

  updateEnemy(index: number, patch: Partial<EnemyState>): void {
    this.enemies.update(enemies =>
      enemies.map((e, i) => i === index ? { ...e, ...patch } : e)
    );
  }

  addLog(msg: string, cls: LogClass = ''): void {
    this.log.update(log => [{ msg, cls }, ...log]);
  }

  // ── Initialization ──
  pick3(): HeroState[] {
    const pool = [...ALL_HEROES];
    const picked: HeroState[] = [];
    while (picked.length < 3 && pool.length > 0) {
      const idx = Math.floor(Math.random() * pool.length);
      picked.push(createHeroState(pool.splice(idx, 1)[0]));
    }
    return picked;
  }

  initHeroes(partyIds?: HeroId[]): void {
    if (partyIds) {
      const heroes = partyIds
        .map(id => ALL_HEROES.find(h => h.id === id))
        .filter((h): h is typeof ALL_HEROES[number] => !!h)
        .map(h => createHeroState(h));
      this.heroes.set(heroes);
    } else {
      this.heroes.set(this.pick3());
    }
  }

  resetHeroForNewRound(index: number): void {
    this.updateHero(index, {
      roll: null,
      rawRoll: null,
      rollNudge: 0,
      confirmed: false,
      lockedTarget: undefined,
      shTgtIdx: null,
      healTgtIdx: null,
      rfmTgtIdx: null,
      reviveTgtIdx: null,
      noRR: false,
      splitAlloc: {},
      _pulseBanked: false,
      _evoRollRecorded: false,
      _actionLogged: false,
    });
  }

  reset(): void {
    this.battle.set(0);
    this.phase.set('player');
    this.heroes.set([]);
    this.enemies.set([]);
    this.target.set(0);
    this.log.set([]);
    this.rfmPen.set(0);
    this.rfmT.set(0);
    this.tauntHeroId.set(null);
    this.pendingEvolutions.set([]);
    this.tutorial.set(null);
    this.protocol.set(0);
    this.selectedHeroIdx.set(null);
    this.pendingProtocol.set(null);
    this.rollAllInProgress.set(false);
    this.rollAnimInProgress.set(false);
    this.squadDiceSettling.set(false);
    this.squadSettleHeroIdx.set(null);
    this.enemyDiceSettling.set(false);
    this.enemyTrayRevealed.set(false);
    this.showOverlay.set(false);
  }
}
