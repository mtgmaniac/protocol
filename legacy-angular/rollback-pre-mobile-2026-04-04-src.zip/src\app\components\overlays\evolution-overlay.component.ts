import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { EvolutionService, GroupedEvoPath } from '../../services/evolution.service';
import { CombatService } from '../../services/combat.service';

@Component({
  selector: 'app-evolution-overlay',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="evo-overlay" [class.show]="isVisible()">
      <div style="font-size:22px;font-weight:900;letter-spacing:5px;color:#fff;margin-bottom:14px;">
        ⬡ EVOLUTION AVAILABLE
      </div>
      <div class="evo-heroes-row">
        @for (pe of state.pendingEvolutions(); track pe.heroIdx; let ci = $index) {
          <div class="evo-hero-card">
            <div style="font-size:14px;font-weight:700;color:#fff;margin-bottom:8px;">
              {{ getHeroName(pe.heroIdx) }}
            </div>
            @for (path of getPaths(pe.heroIdx); track path.name; let ei = $index) {
              <div class="evo-path" [class.selected]="pe.chosen === ei" (click)="selectEvo(ci, ei)">
                <div class="evo-path-name">{{ path.name }}</div>
                <div class="evo-path-focus">{{ path.focus }}</div>
                <div style="font-size:9px;color:var(--muted);margin-top:4px;">
                  HP: {{ path.hp }} | {{ path.abilities.length }} abilities
                </div>
              </div>
            }
          </div>
        }
      </div>
      <button class="evo-confirm-btn" [disabled]="!allChosen()" (click)="confirm()">
        CONFIRM EVOLUTIONS
      </button>
    </div>
  `,
  styles: [`
    .evo-overlay {
      position: fixed; inset: 0; background: rgba(8,12,18,.97);
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      z-index: 600; opacity: 0; pointer-events: none; transition: opacity .3s; overflow-y: auto; padding: 20px;
    }
    .evo-overlay.show { opacity: 1; pointer-events: all; }
    .evo-heroes-row { display: flex; gap: 14px; flex-wrap: wrap; justify-content: center; max-width: 900px; width: 100%; }
    .evo-hero-card { flex: 1; min-width: 240px; max-width: 340px; background: #0d1520; border: 1px solid #2a4f7a; border-radius: 6px; padding: 14px; }
    .evo-path {
      border: 1px solid #1e3a5f; border-radius: 4px; padding: 10px; cursor: pointer;
      transition: all .18s; background: #111d2e; margin-bottom: 8px;
    }
    .evo-path:hover { border-color: #2e7dd4; }
    .evo-path.selected { border-color: #1d9e75; background: rgba(29,158,117,.08); }
    .evo-path-name { font-size: 13px; font-weight: 700; color: #fff; margin-bottom: 2px; }
    .evo-path-focus { font-family: 'Share Tech Mono', monospace; font-size: 10px; color: #4a6a8a; margin-bottom: 5px; }
    .evo-confirm-btn {
      font-family: 'Share Tech Mono', monospace; font-weight: 900; font-size: 14px; letter-spacing: 3px;
      text-transform: uppercase; padding: 11px 38px; border-radius: 3px; cursor: pointer;
      border: 1px solid #1d9e75; background: rgba(29,158,117,.12); color: #1d9e75;
      transition: all .2s; margin-top: 18px;
    }
    .evo-confirm-btn:hover:not(:disabled) { background: rgba(29,158,117,.28); }
    .evo-confirm-btn:disabled { opacity: .3; cursor: not-allowed; }
  `],
})
export class EvolutionOverlayComponent {
  state = inject(GameStateService);
  private evo = inject(EvolutionService);
  private combat = inject(CombatService);

  isVisible = computed(() => this.state.pendingEvolutions().length > 0);

  allChosen = computed(() =>
    this.state.pendingEvolutions().every(pe => pe.chosen !== null)
  );

  getHeroName(heroIdx: number): string {
    return this.state.heroes()[heroIdx]?.name ?? '?';
  }

  getPaths(heroIdx: number): GroupedEvoPath[] {
    const hero = this.state.heroes()[heroIdx];
    if (!hero) return [];
    return this.evo.groupEvoPaths(hero.evolutions);
  }

  selectEvo(pendingIdx: number, pathIdx: number): void {
    this.state.pendingEvolutions.update(evos =>
      evos.map((pe, i) => i === pendingIdx ? { ...pe, chosen: pathIdx } : pe)
    );
  }

  confirm(): void {
    const pending = this.state.pendingEvolutions();
    for (const pe of pending) {
      if (pe.chosen !== null) {
        this.evo.confirmEvolution(pe.heroIdx, pe.chosen);
      }
    }
    this.state.pendingEvolutions.set([]);
    // Show next battle overlay
    this.combat.nextBattle();
  }
}
