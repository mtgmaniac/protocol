export const PROTOCOL_MAX = 100;
export const PROTOCOL_ROUND = 10;
export const PROTOCOL_REROLL_COST = 10;
export const PROTOCOL_NUDGE_COST = 5;
export const PROTOCOL_NUDGE_DELTA = 3;
export const BUILD_VERSION = 'v0.92-savepoint';
export const BUILD_STAMP = '2026-04-01';
