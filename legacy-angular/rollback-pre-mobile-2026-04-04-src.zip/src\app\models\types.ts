export type Zone = 'recharge' | 'strike' | 'surge' | 'crit' | 'overload';
export type GamePhase = 'player' | 'enemy' | 'over';
export type AIType = 'dumb' | 'smart';
export type EnemyType = 'scrap' | 'rust' | 'patrol' | 'guard' | 'warden' | 'volt' | 'boss';
export type LogClass = '' | 'pl' | 'en' | 'sy' | 'bl' | 'vi' | 'de';
export type ProtocolAction = 'reroll' | 'nudge' | null;
export type TargetPickKind = 'enemy' | 'heal' | 'shield' | 'rollBuff' | 'revive' | null;
export type LogMode = 'min' | 'all';
export type HeroId = 'pulse' | 'combat' | 'shield' | 'medic' | 'engineer' | 'ghost';

export const ZONES: Zone[] = ['recharge', 'strike', 'surge', 'crit', 'overload'];

export const ZONE_LABELS: Record<Zone, string> = {
  recharge: 'RECHARGE',
  strike: 'STRIKE',
  surge: 'SURGE',
  crit: 'CRIT',
  overload: 'OVERLOAD',
};

export const ZONE_CLASSES: Record<Zone, string> = {
  recharge: 'az-r',
  strike: 'az-s',
  surge: 'az-su',
  crit: 'az-c',
  overload: 'az-o',
};

export const ZONE_COLORS: Record<Zone, string> = {
  recharge: '#1d9e75',
  strike: '#2e7dd4',
  surge: '#c47a1a',
  crit: '#e8b84a',
  overload: '#d84a2a',
};

export const ZONE_BG: Record<Zone, string> = {
  recharge: '#0a2a1e',
  strike: '#091828',
  surge: '#1e1408',
  crit: '#1e1608',
  overload: '#1e0a06',
};
