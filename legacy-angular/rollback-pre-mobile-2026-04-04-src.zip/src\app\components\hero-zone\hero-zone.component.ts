import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { TargetingService } from '../../services/targeting.service';
import { HeroCardComponent } from './hero-card/hero-card.component';

@Component({
  selector: 'app-hero-zone',
  standalone: true,
  imports: [HeroCardComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="hero-zone-wrap">
      <div class="heroes-zone">
        @for (hero of state.heroes(); track hero.id; let i = $index) {
          <app-hero-card
            [hero]="hero"
            [index]="i"
            [isSelected]="state.selectedHeroIdx() === i"
            [pickMode]="getPickMode(i)"
            (heroClicked)="targeting.onHeroCardClick(i)"
            (allyPickClicked)="targeting.onAllyHeroPickClick(i)" />
        }
      </div>
    </div>
  `,
  styles: [`
    .hero-zone-wrap { display: flex; flex-direction: column; align-items: flex-start; margin: 0; width: 736px; gap: 10px; }
    .heroes-zone { display: flex; flex-direction: row; gap: 8px; margin-bottom: 0; flex-wrap: nowrap; align-items: flex-start; width: 736px; }
  `],
})
export class HeroZoneComponent {
  state = inject(GameStateService);
  targeting = inject(TargetingService);

  getPickMode(i: number): string | null {
    const shi = this.state.selectedHeroIdx();
    if (shi === null) return null;
    const nk = this.targeting.nextPickKindForHero(shi);
    const heroes = this.state.heroes();
    const t = heroes[i];
    if (!t) return null;

    // Targeted heal/shield: any living ally, including the caster (explicit pick required).
    if (nk === 'heal' || nk === 'shield' || nk === 'rollBuff') {
      if (t.currentHp <= 0) return null;
      return nk;
    }
    // Revive: dead allies only; never the living caster card.
    if (nk === 'revive') {
      if (shi === i) return null;
      if (t.currentHp > 0) return null;
      return nk;
    }
    return null;
  }
}
