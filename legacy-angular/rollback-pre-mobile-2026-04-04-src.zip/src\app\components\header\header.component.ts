import { Component, ChangeDetectionStrategy, inject, output } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { BUILD_VERSION, BUILD_STAMP } from '../../models/constants';

@Component({
  selector: 'app-header',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header>
      <div class="logo">OVERLOAD <span>PROTOCOL</span></div>
      <div class="bn" id="tut-battle-counter">BATTLE {{ state.battle() + 1 }} / 10</div>
      <div class="hdr-right">
        <button class="hdr-btn" (click)="helpClicked.emit()">HELP</button>
        <div class="build-tag">{{ version }} · {{ stamp }}</div>
      </div>
    </header>
  `,
  styles: [`
    header { display: flex; align-items: center; justify-content: flex-start; gap: 20px; border-bottom: 1px solid var(--border); padding-bottom: 8px; margin-bottom: 10px; }
    .logo { font-size: 14px; font-weight: 700; letter-spacing: 3px; color: #fff; }
    .logo span { color: var(--overload); }
    .bn { font-size: 16px; color: var(--text); font-weight: 600; }
    .hdr-right { margin-left: auto; display: flex; align-items: center; gap: 10px; }
    .hdr-btn {
      font-family: 'Share Tech Mono', monospace; font-size: 10px; font-weight: 800; letter-spacing: 2px;
      color: var(--text); background: rgba(255,255,255,.03); border: 1px solid var(--border2);
      padding: 4px 8px; border-radius: 3px; cursor: pointer; white-space: nowrap;
    }
    .hdr-btn:hover { border-color: var(--strike); color: var(--strike); }
    .build-tag {
      font-family: 'Share Tech Mono', monospace; font-size: 10px; font-weight: 800; letter-spacing: 2px;
      color: var(--build); background: var(--build-bg); border: 1px solid rgba(29,158,117,.45);
      padding: 4px 8px; border-radius: 3px; white-space: nowrap;
    }
  `],
})
export class HeaderComponent {
  state = inject(GameStateService);
  helpClicked = output<void>();

  version = BUILD_VERSION;
  stamp = BUILD_STAMP;
}
