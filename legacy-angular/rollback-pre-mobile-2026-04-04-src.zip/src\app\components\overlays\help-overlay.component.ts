import { Component, ChangeDetectionStrategy, input, output } from '@angular/core';

@Component({
  selector: 'app-help-overlay',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="help-overlay" [class.show]="isOpen()">
      <div class="help-body">
        <div class="help-top">
          <div class="help-title">HELP & REFERENCE</div>
          <button class="hdr-btn" (click)="closed.emit()">CLOSE</button>
        </div>
        <div class="help-grid">
          <div class="hsec">
            <h3>DICE ZONES</h3>
            <div class="help-mini">
              <div><span class="k">1-4</span> RECHARGE — Low power abilities</div>
              <div><span class="k">5-10</span> STRIKE — Standard abilities</div>
              <div><span class="k">11-16</span> SURGE — Strong abilities</div>
              <div><span class="k">17-19</span> CRIT — Very strong abilities</div>
              <div><span class="k">20</span> OVERLOAD — Maximum power</div>
            </div>
          </div>
          <div class="hsec">
            <h3>PROTOCOL SYSTEM</h3>
            <div class="help-mini">
              <div>Gain <span class="k">10</span> protocol per round (max 100)</div>
              <div><span class="k">REROLL</span> — Re-roll one die (cost: 10)</div>
              <div><span class="k">NUDGE</span> — Add +3 to one die (cost: 5)</div>
            </div>
          </div>
          <div class="hsec">
            <h3>COMBAT</h3>
            <div class="help-mini">
              <div>Each hero rolls a d20 to determine their ability</div>
              <div>Assign targets, then end turn to resolve</div>
              <div>Shields absorb damage before HP</div>
              <div>DoT ticks at the start of each turn</div>
            </div>
          </div>
          <div class="hsec">
            <h3>EVOLUTION</h3>
            <div class="help-mini">
              <div>Heroes earn HRS (Hero Roll Score) each battle</div>
              <div>At 18+ HRS after battle 3, evolution unlocks</div>
              <div>Choose 1 of 2 paths to upgrade abilities</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .help-overlay { position: fixed; inset: 0; background: rgba(8,12,18,.93); display: flex; align-items: center; justify-content: center; z-index: 800; opacity: 0; pointer-events: none; transition: opacity .2s; }
    .help-overlay.show { opacity: 1; pointer-events: all; }
    .help-body { width: min(760px, calc(100vw - 24px)); max-height: calc(100vh - 24px); overflow: auto; background: var(--bg2); border: 1px solid var(--border2); border-radius: 8px; padding: 16px 18px; }
    .help-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 10px; }
    .help-title { font-size: 14px; font-weight: 900; letter-spacing: 3px; color: #fff; }
    .help-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .hsec { border: 1px solid rgba(255,255,255,.08); border-radius: 6px; padding: 10px; background: rgba(255,255,255,.02); }
    .hsec h3 { font-family: 'Share Tech Mono', monospace; font-size: 10px; letter-spacing: 2px; color: var(--muted); margin-bottom: 8px; }
    .help-mini { font-family: 'Share Tech Mono', monospace; font-size: 10px; color: var(--muted); line-height: 1.5; }
    .k { color: #fff; font-weight: 900; }
    .hdr-btn {
      font-family: 'Share Tech Mono', monospace; font-size: 10px; font-weight: 800; letter-spacing: 2px;
      color: var(--text); background: rgba(255,255,255,.03); border: 1px solid var(--border2);
      padding: 4px 8px; border-radius: 3px; cursor: pointer;
    }
    .hdr-btn:hover { border-color: var(--strike); color: var(--strike); }
  `],
})
export class HelpOverlayComponent {
  isOpen = input(false);
  closed = output<void>();
}
