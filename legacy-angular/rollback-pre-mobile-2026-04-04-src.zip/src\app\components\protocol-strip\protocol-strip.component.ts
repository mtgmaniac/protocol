import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { GameStateService } from '../../services/game-state.service';
import { ProtocolService } from '../../services/protocol.service';
import { PROTOCOL_MAX, PROTOCOL_REROLL_COST, PROTOCOL_NUDGE_COST } from '../../models/constants';

@Component({
  selector: 'app-protocol-strip',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="protocol-strip">
      <div class="protocol-bar-wrap">
        <div class="protocol-bar-fill" [style.width]="barWidth()"></div>
        <div class="protocol-bar-txt">PROTOCOL {{ state.protocol() }}/{{ max }}</div>
      </div>
      <div class="protocol-actions">
        <button class="hdr-btn" [class.active]="state.pendingProtocol() === 'reroll'"
                [disabled]="!canReroll()" (click)="protocol.startReroll()">
          REROLL ({{ rerollCost }})
        </button>
        <button class="hdr-btn" [class.active]="state.pendingProtocol() === 'nudge'"
                [disabled]="!canNudge()" (click)="protocol.startNudge()">
          NUDGE +3 ({{ nudgeCost }})
        </button>
      </div>
    </div>
  `,
  styles: [`
    .protocol-strip { display: flex; flex-direction: column; gap: 6px; width: 100%; align-items: stretch; margin-top: 4px; }
    .protocol-bar-wrap { position: relative; height: 28px; border-radius: 4px; border: 1px solid var(--border2); background: #0a1018; overflow: hidden; }
    .protocol-bar-fill { height: 100%; width: 0%; background: linear-gradient(90deg, #1a3a5a, #2e7dd4); transition: width .2s ease; }
    .protocol-bar-txt {
      position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
      font-family: 'Share Tech Mono', monospace; font-size: 11px; font-weight: 700;
      color: #e8f4ff; text-shadow: 0 1px 2px rgba(0,0,0,.85); pointer-events: none;
    }
    .protocol-actions { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: center; }
    .hdr-btn {
      font-family: 'Share Tech Mono', monospace; font-size: 10px; font-weight: 800; letter-spacing: 2px;
      color: var(--text); background: rgba(255,255,255,.03); border: 1px solid var(--border2);
      padding: 6px 10px; border-radius: 3px; cursor: pointer; white-space: nowrap;
    }
    .hdr-btn:hover:not(:disabled) { border-color: var(--strike); color: var(--strike); }
    .hdr-btn:disabled { opacity: .35; cursor: not-allowed; }
    .hdr-btn.active { border-color: var(--strike); color: var(--strike); background: rgba(46,125,212,.1); }
  `],
})
export class ProtocolStripComponent {
  state = inject(GameStateService);
  protocol = inject(ProtocolService);

  max = PROTOCOL_MAX;
  rerollCost = PROTOCOL_REROLL_COST;
  nudgeCost = PROTOCOL_NUDGE_COST;

  barWidth = computed(() => {
    const pct = Math.max(0, Math.min(100, (this.state.protocol() / PROTOCOL_MAX) * 100));
    return pct + '%';
  });

  canReroll = computed(() => {
    if (this.state.phase() !== 'player') return false;
    if (this.state.protocol() < PROTOCOL_REROLL_COST) return false;
    return this.state.heroes().some(h => h.currentHp > 0 && h.roll !== null);
  });

  canNudge = computed(() => {
    if (this.state.phase() !== 'player') return false;
    if (this.state.protocol() < PROTOCOL_NUDGE_COST) return false;
    return this.state.heroes().some(h => {
      if (h.currentHp <= 0 || h.roll === null) return false;
      const eff = Math.min(20, (h.roll || 0) + (h.rollBuff || 0) + (h.rollNudge || 0));
      return eff < 20;
    });
  });
}
