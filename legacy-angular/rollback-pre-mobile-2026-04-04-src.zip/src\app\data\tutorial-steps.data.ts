import { HeroId } from '../models/types';

export const TUTORIAL_PARTY_IDS: HeroId[] = ['pulse', 'shield', 'combat'];

export const TUTORIAL_ROLL_PRESETS: Record<number, Record<number, number>> = {
  1: { 0: 2, 1: 8, 2: 8 },
  2: { 0: 9, 1: 8, 2: 15 },
  3: { 0: 6, 1: 8, 2: 14 },
};

export interface TutorialStep {
  k: string;
  title: string;
  body: string;
  highlight?: string | null;
  wait: string;
  pulseRollAbility?: boolean;
}

const TUTORIAL_STEPS_T1: TutorialStep[] = [
  { k: 'BASICS \u00b7 1/11', title: 'Defeat the enemy squad', body: 'Your goal is to <strong>knock out every enemy</strong>. Your squad is at the <strong>bottom</strong>; hostiles are at the <strong>top</strong>. This campaign has <strong>10 battles</strong> \u2014 this fight is a safe practice run.', highlight: '#tut-enemy-zone', wait: 'next' },
  { k: 'BASICS \u00b7 2/11', title: 'Ability charts', body: 'Each hero\u2019s <strong>ABILITIES</strong> panel lists D20 ranges. Your roll picks which line resolves when you <strong>End turn</strong>.', highlight: '#heroes-zone', wait: 'next' },
  { k: 'BASICS \u00b7 3/11', title: 'Dice tray', body: 'The <strong>dice tray</strong> sits between enemies and squad: enemy dice above, squad dice below.', highlight: '#tut-dice-tray', wait: 'next' },
  { k: 'BASICS \u00b7 4/11', title: 'Roll all dice', body: 'Press <strong>Roll all dice</strong> for everyone. Dice tumble in the tray, then settle under each unit.', highlight: '#main-action-btn', wait: 'roll' },
  { k: 'BASICS \u00b7 5/11', title: 'Roll \u2192 ability', pulseRollAbility: true, body: 'For <strong>Pulse Tech</strong>, the <strong>tray die</strong> lines up with the <strong>ability chart</strong> above it: the number falls in a range \u2014 that row resolves on <strong>End turn</strong>.', highlight: '#tut-step5-ability, #tut-step5-die', wait: 'next' },
  { k: 'BASICS \u00b7 6/11', title: 'Protocol', body: 'You gain <strong>+10 Protocol</strong> at the start of each player round to spend here. <strong>Reroll (10)</strong> replaces one hero\u2019s die. <strong>Nudge +3 (5)</strong> bumps the total; the face shows the <strong>final</strong> value. Press one, then click the highlighted hero.', highlight: '#protocol-reroll-btn, #protocol-nudge-btn', wait: 'protocolCombo' },
  { k: 'BASICS \u00b7 7/11', title: 'Good job!', body: 'Nice work \u2014 Protocol is there when you need to fix a roll.', highlight: null, wait: 'next' },
  { k: 'BASICS \u00b7 8/11', title: 'Target enemies', body: '<strong>Pulse Tech</strong> and <strong>Combat Unit</strong> each need an enemy for their damage. Select one of those heroes, assign an enemy, then do the same for the <strong>other</strong> \u2014 both must have a target.', highlight: '#tut-enemy-focus', wait: 'enemyTgt' },
  { k: 'BASICS \u00b7 9/11', title: 'Shield an ally', body: '<strong>Aegis Disruptor</strong> has a shield ability that needs an ally. Select that hero, then a <strong>highlighted ally</strong>.', highlight: '#tut-hcard-1', wait: 'shieldTgt' },
  { k: 'BASICS \u00b7 10/11', title: 'End turn', body: 'When every hero shows <strong>Ready</strong>, press <strong>End turn</strong> to resolve actions \u2014 then enemies act.', highlight: '#main-action-btn', wait: 'end' },
  { k: 'BASICS \u00b7 11/11', title: 'You\u2019re good to go!', body: 'That covers the basics. Tap <strong>Start Game</strong> to reset this practice battle and play on your own.', highlight: null, wait: 'startGame' },
];

const TUTORIAL_STEPS_T2: TutorialStep[] = [
  { k: 'ROUND 2 \u00b7 1/4', title: 'Round 2 \u2014 enemy just moved', body: 'Enemies took their turn. You gain <strong>+10 Protocol</strong> at the start of each player round.', highlight: '#tut-enemy-zone', wait: 'next' },
  { k: 'ROUND 2 \u00b7 2/4', title: 'Protocol', body: 'Use <strong>Nudge +3 (5)</strong> or <strong>Reroll (10)</strong> (choose the action, then click a hero). <strong>Nudge</strong> shows only the <strong>new total</strong> on the die \u2014 no arithmetic on the face. Reroll only animates that one die.', highlight: '#protocol-strip', wait: 'next' },
  { k: 'ROUND 2 \u00b7 3/4', title: 'Roll again', body: 'Press <strong>Roll all dice</strong> for round two.', highlight: '#main-action-btn', wait: 'roll' },
  { k: 'ROUND 2 \u00b7 4/4', title: 'Finish the turn', body: 'Assign targets as needed, then <strong>End turn</strong> when everyone is ready.', highlight: '#main-action-btn', wait: 'end' },
];

const TUTORIAL_STEPS_T3: TutorialStep[] = [
  { k: 'ROUND 3 \u00b7 1/2', title: 'Final push', body: 'One more volley \u2014 <strong>Roll all dice</strong>, assign targets, and <strong>End turn</strong> to finish the practice drone.', highlight: '#main-action-btn', wait: 'roll' },
  { k: 'ROUND 3 \u00b7 2/2', title: 'End turn', body: 'Resolve damage and clear the fight.', highlight: '#main-action-btn', wait: 'end' },
];

export const FULL_TUTORIAL_STEPS: TutorialStep[] = TUTORIAL_STEPS_T1.concat(TUTORIAL_STEPS_T2).concat(TUTORIAL_STEPS_T3);
