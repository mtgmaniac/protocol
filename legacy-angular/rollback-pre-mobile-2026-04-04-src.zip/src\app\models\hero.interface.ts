import { HeroAbility } from './ability.interface';
import { normalizeHeroAbility } from '../data/hero-ability-normalize';
import { HeroId } from './types';

export interface EvolutionTier {
  name: string;
  focus: string;
  hp: number;
  abilities: HeroAbility[];
}

export interface HeroDefinition {
  id: HeroId;
  name: string;
  cls: string;
  hp: number;
  sk: HeroId;
  abilities: HeroAbility[];
  evolutions: EvolutionTier[];
}

export interface HeroState extends HeroDefinition {
  currentHp: number;
  maxHp: number;
  roll: number | null;
  rawRoll: number | null;
  rollNudge: number;
  rollBuff: number;
  rollBuffT: number;
  confirmed: boolean;
  dot: number;
  dT: number;
  shield: number;
  shT: number;
  shTgtIdx: number | null;
  healTgtIdx: number | null;
  rfmTgtIdx: number | null;
  reviveTgtIdx: number | null;
  lockedTarget: number | undefined;
  cloaked: boolean;
  noRR: boolean;
  splitAlloc: Record<number, number>;
  tier: 1 | 2;
  hrs: number;
  bRolls: number[];
  evolvedTo: string | null;
  _pulseBanked?: boolean;
  _evoRollRecorded?: boolean;
  _actionLogged?: boolean;
}

export function createHeroState(def: HeroDefinition): HeroState {
  const evolutions = def.evolutions.map(e => ({
    ...e,
    abilities: e.abilities.map(normalizeHeroAbility),
  }));
  return {
    ...def,
    abilities: def.abilities.map(normalizeHeroAbility),
    evolutions,
    currentHp: def.hp,
    maxHp: def.hp,
    roll: null,
    rawRoll: null,
    rollNudge: 0,
    rollBuff: 0,
    rollBuffT: 0,
    confirmed: false,
    dot: 0,
    dT: 0,
    shield: 0,
    shT: 0,
    shTgtIdx: null,
    healTgtIdx: null,
    rfmTgtIdx: null,
    reviveTgtIdx: null,
    lockedTarget: undefined,
    cloaked: false,
    noRR: false,
    splitAlloc: {},
    tier: 1,
    hrs: 0,
    bRolls: [],
    evolvedTo: null,
  };
}
