import { HeroId } from '../models/types';

/** 2×3 lineup in `public/heroes/heroes-lineup.png` (1024×682); bottom strip of each cell is label text — cropped out. */
const LINEUP = { src: '/heroes/heroes-lineup.png', w: 1024, h: 682, cols: 3, rows: 2 };
const CELL_W = LINEUP.w / LINEUP.cols;
const CELL_H = LINEUP.h / LINEUP.rows;
/** Fraction of cell height kept (from top), excluding baked-in name labels */
const PORTRAIT_CELL_H_FRAC = 0.78;
const PORTRAIT_H = CELL_H * PORTRAIT_CELL_H_FRAC;

const HERO_LINEUP_GRID: Record<HeroId, readonly [col: number, row: number]> = {
  pulse: [0, 0],
  combat: [1, 0],
  shield: [2, 0],
  medic: [0, 1],
  engineer: [1, 1],
  ghost: [2, 1],
};

export function heroPortraitSvg(id: HeroId): string {
  const [col, row] = HERO_LINEUP_GRID[id];
  const sx = col * CELL_W;
  const sy = row * CELL_H;
  const { src, w, h } = LINEUP;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="93" height="111" viewBox="${sx} ${sy} ${CELL_W} ${PORTRAIT_H}" preserveAspectRatio="xMidYMid meet"><image href="${src}" xlink:href="${src}" x="0" y="0" width="${w}" height="${h}" preserveAspectRatio="none"/></svg>`;
}

export function enSprite(type: string): string {
  const eliteT = new Set(['patrol', 'guard', 'warden']);
  const c = type === 'boss' ? '#d84a2a' : eliteT.has(type) ? '#c47a1a' : type === 'volt' ? '#9a5fd4' : '#4a6a8a';
  if (type === 'boss') return `<svg width="80" height="96" viewBox="0 0 40 44" viewBox="0 0 40 44" fill="none"><rect x="4" y="11" width="32" height="27" rx="2" fill="#1e0a06" stroke="${c}" stroke-width="1.5"/><rect x="8" y="2" width="24" height="13" rx="2" fill="#1e0a06" stroke="${c}" stroke-width="1.5"/><rect x="2" y="9" width="7" height="15" rx="2" fill="#1e0a06" stroke="${c}" stroke-width="1.2"/><rect x="31" y="9" width="7" height="15" rx="2" fill="#1e0a06" stroke="${c}" stroke-width="1.2"/><rect x="10" y="6" width="20" height="4" rx="1" fill="${c}" opacity=".5"/><circle cx="14" cy="8" r="2" fill="${c}"/><circle cx="20" cy="8" r="2" fill="${c}"/><circle cx="26" cy="8" r="2" fill="${c}"/><rect x="10" y="17" width="20" height="2" rx="1" fill="${c}" opacity=".4"/><rect x="10" y="21" width="20" height="2" rx="1" fill="${c}" opacity=".3"/><rect x="10" y="32" width="8" height="8" rx="1" fill="#1e0a06" stroke="${c}" stroke-width="1"/><rect x="22" y="32" width="8" height="8" rx="1" fill="#1e0a06" stroke="${c}" stroke-width="1"/></svg>`;
  if (eliteT.has(type)) return `<svg width="70" height="84" viewBox="0 0 32 38" fill="none"><rect x="4" y="11" width="24" height="21" rx="2" fill="#1e1408" stroke="${c}" stroke-width="1.3"/><rect x="7" y="3" width="18" height="11" rx="2" fill="#1e1408" stroke="${c}" stroke-width="1.3"/><rect x="0" y="11" width="6" height="12" rx="2" fill="#1e1408" stroke="${c}" stroke-width="1"/><rect x="26" y="11" width="6" height="12" rx="2" fill="#1e1408" stroke="${c}" stroke-width="1"/><rect x="9" y="7" width="14" height="3" rx="1" fill="${c}" opacity=".4"/><circle cx="13" cy="8.5" r="1.5" fill="${c}" opacity=".8"/><circle cx="19" cy="8.5" r="1.5" fill="${c}" opacity=".8"/><rect x="8" y="17" width="16" height="2" rx="1" fill="${c}" opacity=".35"/><rect x="8" y="28" width="6" height="6" rx="1" fill="#1e1408" stroke="${c}" stroke-width="1"/><rect x="18" y="28" width="6" height="6" rx="1" fill="#1e1408" stroke="${c}" stroke-width="1"/></svg>`;
  return `<svg width="60" height="72" viewBox="0 0 26 30" fill="none"><rect x="5" y="8" width="16" height="15" rx="2" fill="#0d1520" stroke="${c}" stroke-width="1"/><rect x="7" y="2" width="12" height="9" rx="2" fill="#0d1520" stroke="${c}" stroke-width="1"/><rect x="0" y="8" width="5" height="6" rx="1" fill="#0d1520" stroke="${c}" stroke-width=".8"/><rect x="21" y="8" width="5" height="6" rx="1" fill="#0d1520" stroke="${c}" stroke-width=".8"/><rect x="9" y="4" width="8" height="3" rx="1" fill="${c}" opacity=".35"/><circle cx="11" cy="5.5" r="1" fill="${c}" opacity=".7"/><circle cx="15" cy="5.5" r="1" fill="${c}" opacity=".7"/><rect x="9" y="23" width="3" height="6" rx="1" fill="#0d1520" stroke="${c}" stroke-width=".8"/><rect x="14" y="23" width="3" height="6" rx="1" fill="#0d1520" stroke="${c}" stroke-width=".8"/></svg>`;
}

export function enSpriteCard(type: string): string {
  return enSprite(type)
    .replace(/width="\d+"/, 'width="93"')
    .replace(/height="\d+"/, 'height="111"');
}

export const BDG_SVG: Record<string, string> = {
  bolt: `<svg class="bdg-svg" viewBox="0 0 24 24" fill="none"><path d="M13 2L3 14h8l-1 8 11-14h-8l0-6z" fill="currentColor" opacity=".9"/></svg>`,
  plus: `<svg class="bdg-svg" viewBox="0 0 24 24" fill="none"><path d="M11 5h2v14h-2zM5 11h14v2H5z" fill="currentColor" opacity=".9"/></svg>`,
  shield: `<svg class="bdg-svg" viewBox="0 0 24 24" fill="none"><path d="M12 2l8 4v7c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6l8-4z" fill="currentColor" opacity=".25"/><path d="M12 3.6l6.5 3.2v6.1c0 4.2-2.8 7.1-6.5 7.6-3.7-.5-6.5-3.4-6.5-7.6V6.8L12 3.6z" stroke="currentColor" stroke-width="1.2" opacity=".9"/></svg>`,
  skull: `<svg class="bdg-svg" viewBox="0 0 24 24" fill="none"><path d="M12 3c4.4 0 8 3 8 7.2 0 2.5-1.3 4.6-3.3 5.9V20c0 .6-.4 1-1 1h-1v-2h-2v2h-1v-2h-2v2H8.3c-.6 0-1-.4-1-1v-3.9C5.3 14.8 4 12.7 4 10.2 4 6 7.6 3 12 3z" fill="currentColor" opacity=".25"/><path d="M9.2 10.6c0 .9-.6 1.6-1.4 1.6s-1.4-.7-1.4-1.6.6-1.6 1.4-1.6 1.4.7 1.4 1.6zm8.4 0c0 .9-.6 1.6-1.4 1.6s-1.4-.7-1.4-1.6.6-1.6 1.4-1.6 1.4.7 1.4 1.6z" fill="currentColor" opacity=".9"/><path d="M10.2 15.2h3.6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity=".9"/></svg>`,
  die6: `<svg class="bdg-svg" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <rect x="4.2" y="4.2" width="15.6" height="15.6" rx="3" stroke="currentColor" stroke-width="1.4" opacity=".9"/>
    <circle cx="9" cy="8.5" r="1.35" fill="currentColor" opacity=".95"/>
    <circle cx="9" cy="12" r="1.35" fill="currentColor" opacity=".95"/>
    <circle cx="9" cy="15.5" r="1.35" fill="currentColor" opacity=".95"/>
    <circle cx="15" cy="8.5" r="1.35" fill="currentColor" opacity=".95"/>
    <circle cx="15" cy="12" r="1.35" fill="currentColor" opacity=".95"/>
    <circle cx="15" cy="15.5" r="1.35" fill="currentColor" opacity=".95"/>
  </svg>`,
};
