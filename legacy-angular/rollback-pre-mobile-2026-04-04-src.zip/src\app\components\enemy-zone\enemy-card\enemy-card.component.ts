import { Component, ChangeDetectionStrategy, input, output, computed, inject } from '@angular/core';
import { EnemyState } from '../../../models/enemy.interface';
import { EnemyAbility } from '../../../models/ability.interface';
import { Zone, ZONES } from '../../../models/types';
import { GameStateService } from '../../../services/game-state.service';
import { DiceService } from '../../../services/dice.service';
import { CombatService } from '../../../services/combat.service';
import { HpBarComponent } from '../../shared/hp-bar/hp-bar.component';
import { PortraitFrameComponent } from '../../shared/portrait-frame/portrait-frame.component';
import { AbilityRowComponent } from '../../shared/ability-row/ability-row.component';
import { BadgeZoneComponent } from '../../shared/badge-zone/badge-zone.component';
import { enSpriteCard } from '../../../data/sprites.data';

const ECOL: Record<string, string> = {
  scrap: '#4a6a8a',
  rust: '#5d6478',
  patrol: '#c47a1a',
  guard: '#3a8a72',
  warden: '#a67a3a',
  volt: '#9a5fd4',
  boss: '#d84a2a',
};

@Component({
  selector: 'app-enemy-card',
  standalone: true,
  imports: [HpBarComponent, PortraitFrameComponent, AbilityRowComponent, BadgeZoneComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="ec-col ec-col--stacked"
         [class.selectable-enemy-pick]="isPickable()"
         (click)="onCardClick()">
      <div class="ec-card" [style.border-color]="enemyColor()" [style.opacity]="enemy().dead ? 0.3 : 1">
        <!-- Ability panel -->
        <div class="ap">
          <div class="ap-title">ABILITIES</div>
          @for (zone of zones; track zone) {
            @if (getAbilityForZone(zone); as ab) {
              <app-ability-row
                [ability]="ab"
                [zone]="zone"
                [rangeStr]="enemyRangeStr(zone)"
                [isCurrent]="isCurrentZone(zone)"
                effectVariant="enemy" />
            }
          }
        </div>
        <!-- Bottom info -->
        <div class="ebot">
          <div class="einfo">
            <div>
              <div class="hname">{{ enemy().name }}</div>
              <div class="hero-target-line">
                Target: <span [class]="targetColorClass()">{{ targetName() }}</span>
              </div>
            </div>
            <div>
              <app-hp-bar [current]="enemy().currentHp" [max]="enemy().maxHp" />
              <app-badge-zone kind="enemy" [index]="index()" />
            </div>
          </div>
          <div class="esprite">
            <app-portrait-frame [svg]="enemySvg()" />
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .ec-col { display: flex; flex-direction: column; width: 240px; flex-shrink: 0; }
    .ec-col--stacked { display: flex; flex-direction: column; align-items: stretch; }
    .selectable-enemy-pick { cursor: pointer; box-shadow: 0 0 0 2px rgba(216,74,42,.45); }
    .ec-card { border: 1px solid; border-radius: 4px; background: #0d1520; }
    .ap { padding: 6px 7px 4px; }
    .ap-title { font-family: 'Share Tech Mono', monospace; font-size: 7px; color: #4a6a8a; margin-bottom: 3px; letter-spacing: 1px; }
    .ebot { padding: 6px 7px; display: flex; gap: 6px; align-items: stretch; }
    .einfo { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: space-between; }
    .esprite { flex-shrink: 0; display: flex; align-items: flex-end; }
    .hero-target-line { font-family: 'Share Tech Mono', monospace; font-size: 8px; line-height: 1.35; color: #6f95b3; margin-top: 4px; }
    .hname { font-size: 11px; font-weight: 800; color: #fff; }
    .tgt-muted { color: #4a6a8a; }
    .tgt-ally { color: #2ec46a; font-weight: 700; }
  `],
})
export class EnemyCardComponent {
  private state = inject(GameStateService);
  private dice = inject(DiceService);
  private combat = inject(CombatService);

  enemy = input.required<EnemyState>();
  index = input.required<number>();
  isPickable = input(false);
  hideRoll = input(false);

  enemyClicked = output<void>();

  zones = ZONES;

  enemyColor = computed(() => ECOL[this.enemy().type] ?? '#4a6a8a');

  enemySvg = computed(() => enSpriteCard(this.enemy().type));

  targetName = computed(() => {
    const tgt = this.enemy().targeting;
    if (!tgt) return '---';
    if (this.hideRoll()) return '???';
    const hero = this.state.heroes().find(h => h.id === tgt);
    return hero ? hero.name : '---';
  });

  targetColorClass = computed(() => {
    const tgt = this.enemy().targeting;
    if (!tgt || this.hideRoll()) return 'tgt-muted';
    return 'tgt-ally';
  });

  getAbilityForZone(zone: Zone): EnemyAbility | null {
    const e = this.enemy();
    const ab = this.combat.getEnemyAbility(e, zone);
    return ab?.name === '?' ? null : ab;
  }

  enemyRangeStr(zone: Zone): string {
    return this.dice.enemyZoneRanges()[zone];
  }

  isCurrentZone(zone: Zone): boolean {
    if (this.hideRoll()) return false;
    if (this.enemy().dead) return false;
    return this.dice.getEnemyZone(this.enemy().effRoll) === zone;
  }

  onCardClick(): void {
    this.enemyClicked.emit();
  }
}
